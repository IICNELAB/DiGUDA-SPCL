# -*- coding: utf-8 -*-
# @Time    : 2020/2/14 20:26
# @Author  : Dai PuWei
# @Email   : 771830171@qq.com
# @File    : __init__.py.py
# @Software: PyCharm

def run_main():
    """
       这是主函数
    """


if __name__ == '__main__':
    run_main()