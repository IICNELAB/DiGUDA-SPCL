
### validate
python test.py --path_t ./save/models/vgg13_covidx2_lr_0.0001_decay_5e-07_trial_cos200ep/vgg13_last.pth --dataset SarsCov


### POC
python test.py --path_t ./save/s_model/ResNet50_covidCT_crd_r:1.0_a:1.0_b:0.8_CCT2Sars/ResNet50_last.pth --dataset SarsCov


# DiG-UDA test on MNIST
python test.py --path_t ./save/DiG-UDA/validate_student_model/ResNet50_webcam_crd_r:1.0_a:0.5_b:0.8_w2a_rn101/ResNet50_best.pth --dataset amazon



/home/mori/Programming/MedConDistill/save/DiG-UDA/validate_student_model/