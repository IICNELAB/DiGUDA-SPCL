# sample scripts for running the distillation code
# # use resnet32x4 and resnet8x4 as an example

# # kd
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill kd --model_s resnet8x4 -r 0.1 -a 0.9 -b 0 --trial 1
# python train_student.py --path_t ./save/models/vgg13_vanilla/ckpt_epoch_240.pth --distill kd --model_s vgg8 -r 0.1 -a 0.9 -b 0 --trial 2

# FitNet
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill hint --model_s resnet8x4 -a 0 -b 100 --trial 1
# # AT
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill attention --model_s resnet8x4 -a 0 -b 1000 --trial 1
# # SP
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill similarity --model_s resnet8x4 -a 0 -b 3000 --trial 1
# # CC
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill correlation --model_s resnet8x4 -a 0 -b 0.02 --trial 1
# # VID
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill vid --model_s resnet8x4 -a 0 -b 1 --trial 1
# # RKD
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill rkd --model_s resnet8x4 -a 0 -b 1 --trial 1
# # PKT
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill pkt --model_s resnet8x4 -a 0 -b 30000 --trial 1
# # AB
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill abound --model_s resnet8x4 -a 0 -b 1 --trial 1
# # FT
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill factor --model_s resnet8x4 -a 0 -b 200 --trial 1
# # FSP
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill fsp --model_s resnet8x4 -a 0 -b 50 --trial 1
# # NST
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill nst --model_s resnet8x4 -a 0 -b 50 --trial 1
# # CRD
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill crd --model_s resnet8x4 -a 0 -b 0.8 --trial 1
# python train_student.py --path_t ./save/models/vgg13_vanilla/ckpt_epoch_240.pth --distill crd --model_s vgg8 -r 1 -a 1 -b 0.8 --trial 3

# # CRD+KD
# python train_student.py --path_t ./save/models/resnet32x4_vanilla/ckpt_epoch_240.pth --distill crd --model_s resnet8x4 -a 1 -b 0.8 --trial 1



'''Covid'''
# kd for covidCT
python train_student.py --path_t ./save/models/resnet32x4_covidCT_lr_0.0001_decay_5e-07_trial_0/resnet32x4_last.pth --distill kd --model_s resnet8x4 -r 0.1 -a 0.9 -b 0 --trial 2
# kd for SARS-Covid
python train_student.py --path_t ./save/models/resnet32x4_SarsCov_lr_0.0001_decay_5e-07_trial_0/resnet32x4_last.pth --distill kd --model_s resnet8x4 -r 0.1 -a 0.9 -b 0 --trial 66


### CRD for covidCT
python train_student.py --path_t ./save/models/resnet32x4_covidCT_lr_0.0001_decay_5e-07_trial_0/resnet32x4_last.pth --distill crd --model_s resnet8x4 -r 1 -a 1 -b 0.8 --trial CTTweighted
### CRD for SARS-CovidCT
python train_student.py --path_t ./save/models/resnet32x4_SarsCov_lr_0.0001_decay_5e-07_trial_0/resnet32x4_last.pth --distill crd --model_s resnet8x4 -r 1 -a 1 -b 0.8 --trial trash
### CRD for covidx2
python train_student.py --path_t ./save/models/resnet32x4_covidx2_lr_0.0001_decay_5e-07_trial_cos/resnet32x4_last.pth --distill crd --model_s resnet8x4 -r 1 -a 1 -b 0.8 --trial cos



###POC
python train_student.py --path_t ./save/t-models/vgg13poc_mnist_lr_0.0001_decay_5e-07_trial_cos50ep/vgg13poc_last.pth --epochs 50 --dataset mnist --tgdom mnist_m --model_s vgg13poc -r 1 -a 1 -b 0.8 -tht 1 --trial tomnistm



### DA
python train_student.py --path_t ./save/models/CovidNext50_SarsCov_lr_0.0001_decay_5e-07_trial_200ep/CovidNext50_last.pth --dataset SarsCov --tgdom covidCT --model_s CovidNext50 --batch_size 25 -r 1 -a 0.01 -b 0.01 -tht 1 --trial CN50+dannonly+SARStoCCT


CUDA_VISIBLE_DEVICES=3 nohup python train_student.py --path_t ./save/models/CovidNext50_covidCT_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNext50_last.pth --dataset covidCT --tgdom SarsCov --model_s CovidNext50 --batch_size 16 -r 1 -a 1 -b 0.8 -tht 0 --trial CN50+crd+CCTtoSars &> CN50+crd+CCTtoSars.out&

### CovidNext50,DG
python train_student.py --path_t ./save/models/CovidNext50_covidx2_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNext50_last.pth --dataset covidx2 --tgdom covidCT --model_s CovidNext50 --batch_size 25 -r 1 -a 1 -b 0.8 -tht 1 --trial C2toCCT
### VGG,DG
python train_student.py --path_t ./save/models/vgg13_covidx2_crd_r:1.0_a:1.0_b:0.8_VGGC2toCCT/vgg13_last.pth --dataset covidx2 --tgdom covidCT --model_s vgg13 --batch_size 25 -r 1 -a 1 -b 0.8 -tht 1 --trial C2toCCT




###COVID-Net
#DA
python train_student.py --path_t ./save/t-models/CovidNet_covidCT_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNet_last.pth --dataset covidCT --tgdom SarsCov --model_s CovidNet --batch_size 20 -r 1 -a 1 -b 0.8 -tht 1 --trial CovidNet+all+CCTtoSARS+lastt

#DG
python train_student.py --path_t ./save/models/CovidNet_covidx2_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNet_last.pth --dataset covidx2 --tgdom covidCT --model_s CovidNet --batch_size 20 -r 1 -a 1 -b 0.8 -tht 1 --trial CovidNet+crd+dann+C2toCCT



###AB1-DA
#CN50, CCT to SARS
python train_student.py --path_t ./save/models/CovidNext50_covidCT_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNext50_last.pth --dataset covidCT --tgdom SarsCov --model_s CovidNext50 --batch_size 25 -r 1 -a 0.4 -b 0.32 -tht 1 --trial CN50+0.4crd+dann+CCTtoSARS
#server
CUDA_VISIBLE_DEVICES=6 nohup python train_student.py --path_t ./save/models/CovidNext50_covidCT_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNext50_last.pth --dataset covidCT --tgdom SarsCov --model_s CovidNext50 --batch_size 25 -r 1 -a 1 -b 0.8 -tht 0 --trial CN50+crd+CCTtoSARS &> CN50+crd+CCTtoSARS.out&


###AB2-DG
#CN50, covidx2 to CCT
python train_student.py --path_t ./save/models/CovidNext50_covidx2_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNext50_last.pth --dataset covidx2 --tgdom covidCT --model_s CovidNext50 --batch_size 25 -r 1 -a 1 -b 0.8 -tht 0.5 --trial CN50+crd+0.5dann+C2toCCT

#server
CUDA_VISIBLE_DEVICES=4 nohup python train_student.py --path_t ./save/models/CovidNext50_covidx2_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNext50_last.pth --dataset covidx2 --tgdom covidCT --model_s CovidNext50 --batch_size 25 -r 1 -a 0.01 -b 0.01 -tht 1 --trial CN50+dannonly+C2toCCT &> CN50+dannonly+C2toCCT.out&


###AB2-DA
#CN50, CCT to Sars
python train_student.py --path_t ./save/models/CovidNext50_covidCT_lr_0.0001_decay_5e-07_trial_cos200ep/CovidNext50_last.pth --dataset covidCT --tgdom SarsCov --model_s CovidNext50 --batch_size 25 -r 1 -a 0.01 -b 0.01 -tht 1 --trial CN50+dannonly+CCTtoSars




'''UDA'''
python train_student.py --path_t ./save/t-models/ResNet50_covidCT_lr_0.0001_decay_5e-07_trial_cos200ep/ResNet50_best.pth --dataset covidCT --tgdom SarsCov --model_s ResNet50 --batch_size 32 -r 1 -a 1 -b 0.8 -tht 1 --trial CCT2Sars



#  DiG-UDA
python train_student.py --path_t ./save/DiG-UDA/teacher-models/ResNet101_webcam_lr_0.01_decay_0.0005_trial_2/ResNet101_best.pth --dataset webcam --tgdom amazon --model_s ResNet50 --batch_size 32 --epochs 200 -r 1 -a 0.5 -b 0.8  -tht 1 --trial w2a_rn101


/home/mori/Programming/MedConDistill/save/DiG-UDA/teacher-models/