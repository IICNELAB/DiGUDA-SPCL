# sample scripts for training vanilla teacher models

python train_teacher.py --model wrn_40_2

python train_teacher.py --model resnet56

python train_teacher.py --model resnet110

python train_teacher.py --model resnet32x4

python train_teacher.py --model resnet8x4 --trial cos

python train_teacher.py --model vgg13

python train_teacher.py --model ResNet50

python train_teacher.py --model vgg13 --dataset covidCT

### POC: mnist
python train_teacher.py --model vgg13poc --classes 10 --epochs 50 --dataset mnist -t cos50ep





'''Covid'''
python train_teacher.py --model ResNet50 --classes 2 --batch_size 32 --epochs 200 --dataset covidCT -t cos200ep


CUDA_VISIBLE_DEVICES=3 nohup python train_teacher.py --model CovidNet --epochs 200 --dataset SarsCov -t cos200ep &> CovidNet+Sars+cos200ep.out&




# DiG-UDA 有效性实验
python train_teacher.py --model ResNet34 --classes 10 --epochs 20 --dataset mnist_m -t 1


#  Office-31实验
python train_teacher.py --model ResNet50 --classes 31 --epochs 20 --dataset amazon  -t play
