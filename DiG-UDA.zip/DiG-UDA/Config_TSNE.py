seed = 1
log_interval = 10

bottle_neck = True
batch_size = 32
epochs = 200
cos_anneal = False
momentum = 0.9
l2_decay = 5e-4
can_backbone = 'resnet50'
DATASET_TYPE = 'SingleDataset'
dropout_ratio = (0.0,)
FC_HIDDEN_DIMS = ()
num_domains_bn = 2

lr = 0.01
alpha = 1
T = 2

class_num = 31  # 65 for office-home, 31 for office31
resnet_path = "/home/mori/Programming/MedConDistill/save/DiG-UDA/teacher-models/ResNet50_webcam_lr_0.01_decay_0.0005_trial_2/ResNet50_best.pth"
dann_path = "/home/mori/Programming/MedConDistill/save/DiG-UDA/office31_student_model/S:ResNet50_T:ResNet50_webcam_crd_r:1.0_a:1.0_b:0.8_w2a_5/ResNet50_best.pth"
diguda_path = "/home/mori/Programming/MedConDistill/save/DiG-UDA/office31_student_model/S:ResNet50_T:ResNet50_webcam_crd_r:1.0_a:0.5_b:0.8_w2a_11/ResNet50_best.pth"

net2_backbone = 'ResNet50'
tensorboard_path = 'tensorboard_log/office31/'
root_path = "../DatasetCollection/office31/"
source_name = "webcam"           #
target_name = "amazon"         #
