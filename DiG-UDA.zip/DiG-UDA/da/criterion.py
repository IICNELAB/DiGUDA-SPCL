import torch
from torch import nn
from torch.autograd import Function


class ReverseLayerF(Function):
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha

        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        output = grad_output.neg() * ctx.alpha

        return output, None


class DomClassifier(nn.Module):
    '''Domain Classifier Module'''
    def __init__(self, dim_in=512, dim_mid=100):     ### dim_in=512[CovidNext] or 12544[Resnet]
        super(DomClassifier, self).__init__()
        self.domain_classifier = nn.Sequential()
        self.domain_classifier.add_module('dom_fc1', nn.Linear(dim_in, dim_mid))
        self.domain_classifier.add_module('dom_bn1', nn.BatchNorm1d(dim_mid))
        self.domain_classifier.add_module('dom_relu1', nn.ReLU(True))
        self.domain_classifier.add_module('dom_fc2', nn.Linear(dim_mid, 2))
        self.domain_classifier.add_module('dom_softmax', nn.LogSoftmax(dim=1))

    def forward(self, feat_in, alpha):          ### feat_in's shape: [batchsize, dim_in]
        reverse_feature = ReverseLayerF.apply(feat_in, alpha)
        domain_output = self.domain_classifier(reverse_feature)
        return domain_output


class DomLoss(nn.Module):
    def __init__(self, opt):
        super(DomLoss, self).__init__()
        self.domain_classifier = DomClassifier(dim_in=opt.dim_in)
        self.loss_domain = nn.NLLLoss()
    
    def forward(self, feat_source, feat_target, alpha):
        source_domain_output = self.domain_classifier(feat_source, alpha)
        target_domain_output = self.domain_classifier(feat_target, alpha)
        source_domain_label = torch.zeros(source_domain_output.shape[0]).long()
        target_domain_label = torch.ones(target_domain_output.shape[0]).long()
        if torch.cuda.is_available():
            source_domain_label, target_domain_label = source_domain_label.cuda(), target_domain_label.cuda()
        # print('source_domain_output: ', source_domain_output.shape)
        loss_dom_source = self.loss_domain(source_domain_output, source_domain_label)
        loss_dom_target = self.loss_domain(target_domain_output, target_domain_label)

        return loss_dom_source, loss_dom_target


# if __name__ == '__main__':
#     import torch

#     feat_in = torch.randn(2, 512)
#     domain_label = torch.tensor([1,0])
#     print(domain_label)
#     loss_dom = DomLoss()
#     print(loss_dom(feat_in,0.5,domain_label))

