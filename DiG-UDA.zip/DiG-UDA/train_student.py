"""
the general training framework
"""

from __future__ import print_function
# from operator import attrgetter

import os
import argparse
import time

import tensorboard_logger as tb_logger
import torch
from torch.nn.modules import module
import torch.optim as optim
import torch.nn as nn
import torch.backends.cudnn as cudnn


from models import model_dict
from models.util import Embed, ConvReg, LinearEmbed
from models.util import Connector, Translator, Paraphraser

# from dataset.cifar100 import get_cifar100_dataloaders, get_cifar100_dataloaders_sample
# from dataset.covidCT import get_covidCT_dataloaders, get_covidCT_dataloaders_sample, target_domain_trainloaders
from dataset.mnist import getMnist
from dataset.office import load_training, load_testing, get_office31_dataloaders_sample, office31_target_domain_trainloaders


from helper.util import adjust_learning_rate, adjust_lr_cos, adjust_grl_cos

from distiller_zoo import DistillKL, HintLoss, Attention, Similarity, Correlation, VIDLoss, RKDLoss
from distiller_zoo import PKT, ABLoss, FactorTransfer, KDSVD, FSP, NSTLoss
from crd.criterion import CRDLoss
from da.criterion import DomLoss

from helper.loops import train_distill as train, validate
from helper.pretrain import init


def parse_option():

    parser = argparse.ArgumentParser('argument for training')

    parser.add_argument('--classes', type=int, default=31,
                        help='number of classes')
    parser.add_argument('--dataset_path', type=str,
                        default='./Office31data', help='dataset path')
    parser.add_argument('--print_freq', type=int,
                        default=40, help='print frequency')
    parser.add_argument('--tb_freq', type=int,
                        default=500, help='tb frequency')
    parser.add_argument('--save_freq', type=int,
                        default=40, help='save frequency')
    parser.add_argument('--batch_size', type=int,
                        default=32, help='batch_size')
    parser.add_argument('--num_workers', type=int,
                        default=1, help='num of workers to use')
    parser.add_argument('--epochs', type=int, default=20,
                        help='number of training epochs')
    parser.add_argument('--init_epochs', type=int, default=30,
                        help='init training for two-stage methods')

    # optimization
    parser.add_argument('--learning_rate', type=float,
                        default=1e-2, help='learning rate')
    # parser.add_argument('--lr_decay_epochs', type=str,
    #                     default='130,155,180', help='where to decay lr, can be a list')
    parser.add_argument('--lr_sttg', type=str, default='grl',
                        choices=['grl', 'cos', 'epoch_dec'], help='learning rate adjust strategy')
    # parser.add_argument('--lr_decay_rate', type=float,
    #                     default=0.1, help='decay rate for learning rate')
    parser.add_argument('--weight_decay', type=float,
                        default=5e-4, help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.9, help='momentum')

    # dataset
    # parser.add_argument('--dataset', type=str, default='SarsCov', choices=[
    #                     'cifar100', 'covidCT', 'SarsCov', 'covidx2', 'mnist', 'mnist_m', 'mnist_2', 'amazon', 'dslr', 'webcam'], help='dataset')
    parser.add_argument('--dataset', type=str, default='amazon', choices=[
        'mnist', 'mnist_m', 'mnist_2', 'amazon', 'dslr', 'webcam'], help='dataset')

    # model
    parser.add_argument('--model_s', type=str, default='ResNet50',
                        choices=['resnet8', 'resnet14', 'resnet20', 'resnet32', 'resnet44', 'resnet56', 'resnet110',
                                 'resnet8x4', 'resnet32x4', 'wrn_16_1', 'wrn_16_2', 'wrn_40_1', 'wrn_40_2',
                                 'vgg8', 'vgg11', 'vgg13', 'vgg13poc', 'vgg16', 'vgg19', 'ResNet50', 'ResNet34',
                                 'MobileNetV2', 'ShuffleV1', 'ShuffleV2', 'CovidNext50', 'CovidNet'])

    parser.add_argument('--path_t', type=str, default=None,
                        help='teacher model snapshot')

    # domain adaption and domain generalization
    # parser.add_argument('--tgdom', type=str, default='None', choices=['SarsCov', 'covidCT', 'covidx2', 'None',
    #                                                                   'mnist', 'mnist_m', 'mnist_2', 'amazon', 'dslr', 'webcam'], help='target domain for domain adaption or domain generalization')
    parser.add_argument('--tgdom', type=str, default='None', choices=['None', 'mnist', 'mnist_m', 'amazon',
                                                                      'dslr', 'webcam'], help='target domain for domain adaption or domain generalization')

    # distillation
    parser.add_argument('--distill', type=str, default='crd', choices=['kd', 'hint', 'attention', 'similarity',
                                                                       'correlation', 'vid', 'crd', 'kdsvd', 'fsp',
                                                                       'rkd', 'pkt', 'abound', 'factor', 'nst'])
    parser.add_argument('-t', '--trial', type=str,
                        default='0', help='trial id')

    parser.add_argument('-r', '--gamma', type=float,
                        default=1, help='weight for CE loss')
    parser.add_argument('-a', '--alpha', type=float,
                        default=None, help='weight balance for KD loss')
    parser.add_argument('-b', '--beta', type=float,
                        default=None, help='weight balance for contrast loss')
    parser.add_argument('-tht', '--theta', type=float,
                        default=1, help='weight balance for DANN')

    # KL distillation
    parser.add_argument('--kd_T', type=float, default=20,
                        help='temperature for KD distillation')

    # NCE distillation
    parser.add_argument('--feat_dim', default=128,
                        type=int, help='feature dimension')
    parser.add_argument('--mode', default='exact',
                        type=str, choices=['exact', 'relax'])
    parser.add_argument('--nce_k', default=128, type=int,
                        help='number of negative samples for NCE')  # 16384=2^14

    parser.add_argument('--nce_t', default=0.5, type=float,     # 0.07
                        help='temperature parameter for softmax')
    parser.add_argument('--nce_m', default=0.5, type=float,
                        help='momentum for non-parametric updates')

    # hint layer
    parser.add_argument('--hint_layer', default=2,
                        type=int, choices=[0, 1, 2, 3, 4])

    opt = parser.parse_args()

    # set different learning rate from these 4 models
    # if opt.model_s in ['MobileNetV2', 'ShuffleV1', 'ShuffleV2']:
    #     opt.learning_rate = 0.01

    # set the path according to the environment
    # if opt.dataset == 'cifar100':
    #     opt.model_path = './save/student_model'
    #     opt.tb_path = './save/student_tensorboards'
    # elif opt.dataset in ['covidCT', 'SarsCov', 'covidx2']:
    #     opt.model_path = './save/s_model'
    #     opt.tb_path = './save/s_tensorboards'
    if opt.dataset in ['mnist', 'mnist_m', 'mnist_2']:
        opt.model_path = './save/DiG-UDA/mnist_student_model'
        opt.tb_path = './save/DiG-UDA/mnist_student_tensorboards'
    elif opt.dataset in ['amazon', 'dslr', 'webcam']:
        opt.model_path = './save/DiG-UDA/office31_student_model'
        opt.tb_path = './save/DiG-UDA/office31_student_tensorboards'

    # iterations = opt.lr_decay_epochs.split(',')
    # opt.lr_decay_epochs = list([])
    # for it in iterations:
    #     opt.lr_decay_epochs.append(int(it))

    opt.model_t = get_teacher_name(opt.path_t)

    opt.model_name = 'S:{}_T:{}_{}_{}_r:{}_a:{}_b:{}_{}'.format(opt.model_s, opt.model_t, opt.dataset, opt.distill,
                                                                opt.gamma, opt.alpha, opt.beta, opt.trial)

    opt.tb_folder = os.path.join(opt.tb_path, opt.model_name)
    if not os.path.isdir(opt.tb_folder):
        os.makedirs(opt.tb_folder)

    opt.save_folder = os.path.join(opt.model_path, opt.model_name)
    if not os.path.isdir(opt.save_folder):
        os.makedirs(opt.save_folder)

    return opt


def get_teacher_name(model_path):
    """parse teacher name"""
    segments = model_path.split('/')[-2].split('_')
    if segments[0] != 'wrn':
        return segments[0]
    else:
        return segments[0] + '_' + segments[1] + '_' + segments[2]


def load_teacher(model_path, n_cls):
    print('==> loading teacher model')

    model_t = get_teacher_name(model_path)
    # print(model_t)
    model = model_dict[model_t](num_classes=n_cls)
    model.load_state_dict(torch.load(model_path)['model'])

    print('==> done')
    return model


def main():
    best_acc = 0

    opt = parse_option()

    # tensorboard logger
    logger = tb_logger.Logger(logdir=opt.tb_folder, flush_secs=2)

    # dataloader
    # if opt.dataset == 'cifar100':
    #     if opt.distill in ['crd']:
    #         train_loader, val_loader, n_data = get_cifar100_dataloaders_sample(batch_size=opt.batch_size,
    #                                                                            num_workers=opt.num_workers,
    #                                                                            k=opt.nce_k,
    #                                                                            mode=opt.mode)
    #     else:
    #         train_loader, val_loader, n_data = get_cifar100_dataloaders(batch_size=opt.batch_size,
    #                                                                     num_workers=opt.num_workers,
    #                                                                     is_instance=True)
    #     n_cls = opt.classes
    # elif opt.dataset in ['covidCT', 'SarsCov', 'covidx2']:
    #     if opt.distill in ['crd']:
    #         train_loader, val_loader, n_data, val_n_data = get_covidCT_dataloaders_sample(opt, batch_size=opt.batch_size,
    #                                                                                       num_workers=opt.num_workers,
    #                                                                                       k=opt.nce_k,
    #                                                                                       samplemode=opt.mode)
    #         # print('n_data: ', n_data)
    #     else:
    #         train_loader, val_loader, n_data, val_n_data = get_covidCT_dataloaders(
    #             opt, is_instance=True)
    #     n_cls = opt.classes
    if opt.dataset in ['mnist', 'mnist_m', 'mnist_2']:
        opt.distill = 'kd'
        train_loader, val_loader, n_data, val_n_data = getMnist(
            deform=opt.dataset)
        n_cls = 10
        opt.classes = 10
    elif opt.dataset in ['amazon', 'dslr', 'webcam']:
        opt.distill = 'crd'
        n_cls = opt.classes = 31
        kwargs = {'num_workers': opt.num_workers, 'pin_memory': True}
        train_loader, val_loader, n_data, _ = get_office31_dataloaders_sample(opt, batch_size=opt.batch_size,
                                                                              num_workers=opt.num_workers,
                                                                              k=opt.nce_k,
                                                                              samplemode=opt.mode)
        #  try load_testing [work!]
        # root_path = "../DatasetCollection/office31/"
        # val_loader, _ = load_testing(root_path, opt.dataset, opt.batch_size, kwargs)
    else:
        raise NotImplementedError(opt.dataset)

    # dataloader for domain adaption
    # if opt.tgdom == 'covidCT':
    #     target_domain_loader, _ = target_domain_trainloaders(
    #         opt, target_domain='covidCT')
    # elif opt.tgdom == 'SarsCov':
    #     target_domain_loader, _ = target_domain_trainloaders(
    #         opt, target_domain='SarsCov')
    # elif opt.tgdom == 'covidx2':
    #     target_domain_loader, _ = target_domain_trainloaders(
    #         opt, target_domain='covidx2')
    if opt.tgdom in ['mnist', 'mnist_m']:
        target_domain_loader, _, _, _ = getMnist(deform=opt.tgdom)
    elif opt.tgdom in ['amazon', 'dslr', 'webcam']:
        target_domain_loader, _ = office31_target_domain_trainloaders(
            opt, target_domain=opt.tgdom)
    elif opt.tgdom != 'None':
        raise NotImplementedError(opt.tgdom)

    # model
    model_t = load_teacher(opt.path_t, n_cls)
    model_s = model_dict[opt.model_s](num_classes=n_cls)

    if opt.dataset in ['mnist', 'mnist_m', 'mnist_2']:
        data = torch.randn(2, 3, 28, 28)
    else:
        data = torch.randn(2, 3, 224, 224)
    model_t.eval()
    model_s.eval()
    feat_t, _ = model_t(data, is_feat=True)
    feat_s, _ = model_s(data, is_feat=True)

    module_list = nn.ModuleList([])
    module_list.append(model_s)
    trainable_list = nn.ModuleList([])
    trainable_list.append(model_s)

    ''' Define Loss '''
    criterion_cls = nn.CrossEntropyLoss()
    criterion_div = DistillKL(opt.kd_T)

    if opt.distill == 'kd':
        criterion_kd = DistillKL(opt.kd_T)
    elif opt.distill == 'hint':
        criterion_kd = HintLoss()
        regress_s = ConvReg(feat_s[opt.hint_layer].shape,
                            feat_t[opt.hint_layer].shape)
        module_list.append(regress_s)
        trainable_list.append(regress_s)
    elif opt.distill == 'crd':
        opt.s_dim = feat_s[-1].shape[1]
        opt.t_dim = feat_t[-1].shape[1]
        opt.n_data = n_data
        criterion_kd = CRDLoss(opt)
        module_list.append(criterion_kd.embed_s)
        module_list.append(criterion_kd.embed_t)
        trainable_list.append(criterion_kd.embed_s)
        trainable_list.append(criterion_kd.embed_t)
    elif opt.distill == 'attention':
        criterion_kd = Attention()
    elif opt.distill == 'nst':
        criterion_kd = NSTLoss()
    elif opt.distill == 'similarity':
        criterion_kd = Similarity()
    elif opt.distill == 'rkd':
        criterion_kd = RKDLoss()
    elif opt.distill == 'pkt':
        criterion_kd = PKT()
    elif opt.distill == 'kdsvd':
        criterion_kd = KDSVD()
    elif opt.distill == 'correlation':
        criterion_kd = Correlation()
        embed_s = LinearEmbed(feat_s[-1].shape[1], opt.feat_dim)
        embed_t = LinearEmbed(feat_t[-1].shape[1], opt.feat_dim)
        module_list.append(embed_s)
        module_list.append(embed_t)
        trainable_list.append(embed_s)
        trainable_list.append(embed_t)
    elif opt.distill == 'vid':
        s_n = [f.shape[1] for f in feat_s[1:-1]]
        t_n = [f.shape[1] for f in feat_t[1:-1]]
        criterion_kd = nn.ModuleList(
            [VIDLoss(s, t, t) for s, t in zip(s_n, t_n)]
        )
        # add this as some parameters in VIDLoss need to be updated
        trainable_list.append(criterion_kd)
    elif opt.distill == 'abound':
        s_shapes = [f.shape for f in feat_s[1:-1]]
        t_shapes = [f.shape for f in feat_t[1:-1]]
        connector = Connector(s_shapes, t_shapes)
        # init stage training
        init_trainable_list = nn.ModuleList([])
        init_trainable_list.append(connector)
        init_trainable_list.append(model_s.get_feat_modules())
        criterion_kd = ABLoss(len(feat_s[1:-1]))
        init(model_s, model_t, init_trainable_list,
             criterion_kd, train_loader, logger, opt)
        # classification
        module_list.append(connector)
    elif opt.distill == 'factor':
        s_shape = feat_s[-2].shape
        t_shape = feat_t[-2].shape
        paraphraser = Paraphraser(t_shape)
        translator = Translator(s_shape, t_shape)
        # init stage training
        init_trainable_list = nn.ModuleList([])
        init_trainable_list.append(paraphraser)
        criterion_init = nn.MSELoss()
        init(model_s, model_t, init_trainable_list,
             criterion_init, train_loader, logger, opt)
        # classification
        criterion_kd = FactorTransfer()
        module_list.append(translator)
        module_list.append(paraphraser)
        trainable_list.append(translator)
    elif opt.distill == 'fsp':
        s_shapes = [s.shape for s in feat_s[:-1]]
        t_shapes = [t.shape for t in feat_t[:-1]]
        criterion_kd = FSP(s_shapes, t_shapes)
        # init stage training
        init_trainable_list = nn.ModuleList([])
        init_trainable_list.append(model_s.get_feat_modules())
        init(model_s, model_t, init_trainable_list,
             criterion_kd, train_loader, logger, opt)
        # classification training
        pass
    else:
        raise NotImplementedError(opt.distill)

    ''' DANN loss '''
    if opt.tgdom != 'None':
        # print('Hello dann')
        opt.dim_in = feat_s[-1].shape[1]
        criterion_dom = DomLoss(opt)
        module_list.append(criterion_dom.domain_classifier)
        trainable_list.append(criterion_dom.domain_classifier)

    criterion_list = nn.ModuleList([])
    criterion_list.append(criterion_cls)    # 0. classification loss
    # 1. KL divergence loss, original knowledge distillation
    criterion_list.append(criterion_div)
    # 2. other knowledge distillation loss
    criterion_list.append(criterion_kd)
    if opt.tgdom != 'None':
        criterion_list.append(criterion_dom)    # 3. domain loss

    # optimizer SGD
    optimizer = optim.SGD(
        trainable_list.parameters(),
        lr=opt.learning_rate,
        momentum=opt.momentum,
        weight_decay=opt.weight_decay)

    # optimizer Adam
    # optimizer = optim.Adam(trainable_list.parameters(),
    #                        lr=opt.learning_rate,
    #                        weight_decay=opt.weight_decay)

    # append teacher after optimizer to avoid weight_decay
    module_list.append(model_t)

    if torch.cuda.is_available():
        module_list = module_list.cuda()
        criterion_list = criterion_list.cuda()
        cudnn.benchmark = True

    # validate teacher accuracy
    teacher_acc, _, _, _ = validate(
        val_loader, model_t, criterion_cls, opt)
    # '\tteacher F1 score: ', teacher_F1)
    print('teacher accuracy: ', teacher_acc)

    # routine
    for epoch in range(1, opt.epochs + 1):
        # choose LR strategy
        if opt.lr_sttg == 'epoch_dec':
            print("==> LR decline/epoch...")
            adjust_learning_rate(epoch, opt, optimizer)
        elif opt.lr_sttg == 'grl':
            print("==> LR decline grl-like...")
            adjust_grl_cos(epoch, opt, optimizer)
        else:
            raise NotImplementedError(opt.lr_sttg)
        print("==> training...")

        time1 = time.time()
        if opt.tgdom != 'None':
            train_acc, train_loss, train_F1, source_dom_loss, target_dom_loss = train(
                epoch, module_list, criterion_list, optimizer, opt, train_loader, target_domain_loader)
        else:
            train_acc, train_loss, train_F1 = train(
                epoch, module_list, criterion_list, optimizer, opt, train_loader, None)
        time2 = time.time()
        print('epoch {}, total time {:.2f}'.format(epoch, time2 - time1))

        logger.log_value('train_acc', train_acc, epoch)
        logger.log_value('train_loss', train_loss, epoch)
        logger.log_value('train_F1', train_F1, epoch)
        if opt.tgdom != 'None':
            logger.log_value('source_dom_loss', source_dom_loss, epoch)
            logger.log_value('target_dom_loss', target_dom_loss, epoch)

        test_acc, test_loss, test_F1, _ = validate(
            val_loader, model_s, criterion_cls, opt)

        logger.log_value('test_acc', test_acc, epoch)
        logger.log_value('test_loss', test_loss, epoch)
        logger.log_value('test_F1', test_F1, epoch)
        # save the best model
        if test_acc > best_acc:
            best_acc = test_acc
            state = {
                'epoch': epoch,
                'model': model_s.state_dict(),
                'best_acc': best_acc,
                'F1 Score': test_F1,
            }
            save_file = os.path.join(
                opt.save_folder, '{}_best.pth'.format(opt.model_s))
            print('saving the best model!')
            torch.save(state, save_file)

        # regular saving
        if epoch % opt.save_freq == 0:
            print('==> Saving...')
            state = {
                'epoch': epoch,
                'model': model_s.state_dict(),
                'accuracy': test_acc,
                'F1 Score': test_F1,
            }
            save_file = os.path.join(
                opt.save_folder, 'ckpt_epoch_{epoch}.pth'.format(epoch=epoch))
            torch.save(state, save_file)

    # This best accuracy is only for printing purpose.
    # The results reported in the paper/README is from the last epoch.
    print('best accuracy:', best_acc)

    # save model
    state = {
        'opt': opt,
        'model': model_s.state_dict(),
    }
    save_file = os.path.join(
        opt.save_folder, '{}_last.pth'.format(opt.model_s))
    torch.save(state, save_file)


if __name__ == '__main__':
    main()
