import torch
from torch import nn
from torchvision import models
from torchsummary import summary


class Trainable(nn.Module):
    """
    Wraps an arbitrary module with a Trainable module. The Trainable module
    is used as a wrapper for freezing and thawing module layers.
    """
    def __init__(self, module, name, trainable=True):
        super().__init__()
        self.module = module
        self.name = name
        self.trainable_switch(trainable)

    def __call__(self, *args, **kwargs):
        return self.module(*args, **kwargs)

    def trainable_switch(self, trainable):
        """
        Makes module layers trainable or not.
        :param trainable: bool, False to freeze the layers, True to unfreeze
         them.
        """
        for p in self.parameters():
            p.requires_grad = trainable


def ConvBn2d(in_dim, out_dim, kernel_size,
             activation=nn.LeakyReLU(0.1, inplace=True)):
    """
    Wraps Conv2D, Batch Normalization 2D, and an arbitrary activation layers
     with a nn.Sequential layer.
    :param in_dim: int, Input feature map dimension
    :param out_dim: int, Output feature map dimension
    :param kernel_size: int or tuple, Convolution kernel size
    :return: nn.Sequential structure containing above listed network layers
    """
    padding = kernel_size // 2
    net = nn.Sequential(
        nn.Conv2d(in_dim, out_dim, kernel_size=kernel_size,
                  padding=padding, bias=False),
        nn.BatchNorm2d(out_dim),
        activation)
    return net

class COVIDNext50(nn.Module):
    def __init__(self, num_classes):
        super(COVIDNext50, self).__init__()
        self.n_classes = num_classes
        trainable = True

        # Layers
        backbone = models.resnext50_32x4d(pretrained=True)
        self.block0 = Trainable(nn.Sequential(
                                    backbone.conv1,
                                    backbone.bn1,
                                    backbone.relu,
                                    backbone.maxpool),
                                trainable=trainable,
                                name="conv1")
        self.block1 = Trainable(backbone.layer1,
                                trainable=trainable,
                                name="block1")
        self.block2 = Trainable(backbone.layer2,
                                trainable=trainable,
                                name="block2")
        self.block3 = Trainable(backbone.layer3,
                                trainable=trainable,
                                name="block3")
        self.block4 = Trainable(backbone.layer4,
                                trainable=trainable,
                                name="block4")
        self.backbone_end = Trainable(nn.Sequential(
                                        ConvBn2d(2048, 512, 3),
                                        ConvBn2d(512, 1024, 1),
                                        ConvBn2d(1024, 512, 3)),
                                      name="back",
                                      trainable=True)
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.logits = Trainable(nn.Linear(512, self.n_classes),
                                name="logits",
                                trainable=True)

    def forward(self, input, is_feat=False, preact=False):
        net = input
        for layer in [self.block0, self.block1, self.block2, self.block3,
                      self.block4]:
            net = layer(net)
        net = self.backbone_end(net)
        net = self.avg_pool(net)        # torch.Size([2, 512, 1, 1])
        net = net.squeeze(-1).squeeze(-1)      # torch.Size([2, 512])
        f1=[net]
        net = self.logits(net)
        if is_feat:
            return f1, net
        else:
            return net

    def probability(self, logits):
        return nn.functional.softmax(logits, dim=-1)




if __name__ == '__main__':
    import torch

    x = torch.randn(1, 3, 224, 224)
    net = COVIDNext50(num_classes=2)
    logit = net(x) #, is_feat=True)
    print(logit)        # tensor([ 0.1693, -0.1489], grad_fn=<AddBackward0>)
    '''using torchsummary '''
    # net = net.cuda()
    # summary(net,(3,224,224))



    '''using loop and print'''
    # for f in feats:
    #     print(f.shape)#, f.min().item())
    # print(logit.shape)

    # for m in net.get_bn_before_relu():
    #     if isinstance(m, nn.BatchNorm2d):
    #         print('pass')
    #     else:
    #         print('warning')