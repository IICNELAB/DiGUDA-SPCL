from __future__ import print_function, division
# import da
# from dataset.covidCT import target_domain_trainloaders

import sys
import time
import torch
from torch import t, topk
import numpy as np
from .util import AverageMeter, accuracy, f1
from sklearn.metrics import roc_curve, auc, roc_auc_score, f1_score


def train_vanilla(epoch, train_loader, model, criterion, optimizer, opt):
    """vanilla training teacher"""
    model.train()

    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    F1Score = AverageMeter()

    end = time.time()
    # for non-sample style dataloader
    # for idx, (input, target) in enumerate(train_loader):
    # for sample style dataloader
    for idx, (input, target, _, _) in enumerate(train_loader):
        data_time.update(time.time() - end)

        input = input.float()
        if torch.cuda.is_available():
            input = input.cuda()
            target = target.cuda()

        # ===================forward=====================
        # print('input model.....')
        output = model(input)
        # print(type(output),type(target))
        # print('model output....')
        loss = criterion(output, target)

        # for cifar
        # acc1, acc5 = accuracy(output, target, topk=(1, 5))

        # for covid/mnist
        acc1 = accuracy(output, target)
        f1Score = f1(output, target)
        losses.update(loss.item(), input.size(0))
        top1.update(acc1[0], input.size(0))
        F1Score.update(f1Score, input.size(0))

        # ===================backward=====================
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # ===================meters=====================
        batch_time.update(time.time() - end)
        end = time.time()

        # tensorboard logger
        pass

        # print info
        if idx % opt.print_freq == 0:
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Acc@1 {top1.val:.3f} ({top1.avg:.3f})\t'
                  'F1 Score {F1Score.val:.3f} ({F1Score.avg:.3f})'
                  .format(epoch, idx, len(train_loader), batch_time=batch_time,
                          data_time=data_time, loss=losses, top1=top1, F1Score=F1Score))
            sys.stdout.flush()

    print(' * Acc@1 {top1.avg:.3f}\t' '\tF1 Score {F1Score.avg:.3f}'
          .format(top1=top1, F1Score=F1Score))

    return top1.avg, losses.avg, F1Score.avg


def train_distill(epoch, module_list, criterion_list, optimizer, opt, train_loader, target_domain_loader=None):
    """Every epoch distillation"""
    # set modules as train()
    for module in module_list:
        module.train()
    # set teacher as eval()
    module_list[-1].eval()

    if opt.distill == 'abound':
        module_list[1].eval()
    elif opt.distill == 'factor':
        module_list[2].eval()

    criterion_cls = criterion_list[0]
    criterion_div = criterion_list[1]
    criterion_kd = criterion_list[2]
    if opt.tgdom != 'None':
        critetion_dom = criterion_list[3]

    model_s = module_list[0]
    model_t = module_list[-1]

    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    F1Score = AverageMeter()
    if opt.tgdom != 'None':
        source_dom_loss = AverageMeter()
        target_dom_loss = AverageMeter()

    end = time.time()

    idx = 0
    train_loader_iter = iter(train_loader)
    len_source_loader = len(train_loader)
    target_loader_iter = iter(target_domain_loader)
    len_target_loader = len(target_domain_loader)

    # if opt.tgdom != 'None':
    #     loader_len = min(len(train_loader), len(target_domain_loader))
    #     target_loader_iter = iter(target_domain_loader)
    # else:
    # loader_len = len(train_loader)

    while idx < len_source_loader:
        data = next(train_loader_iter)
        if idx % len_target_loader == 0:
            target_loader_iter = iter(target_domain_loader)
        if opt.tgdom != 'None':
            target_data = next(target_loader_iter)
            target_input, _ = target_data

        if opt.distill in ['crd']:
            input, target, index, contrast_idx = data
        elif opt.dataset in ['mnist', 'mnist_m', 'mnist_2']:
            input, target = data
        else:
            input, target, index, _ = data

        data_time.update(time.time() - end)

        input = input.float()
        if opt.tgdom != 'None':
            target_input = target_input.float()

        if torch.cuda.is_available():
            input = input.cuda()
            target = target.cuda()
            if opt.dataset not in ['mnist', 'mnist_m', 'mnist_2']:
                index = index.cuda()
            if opt.tgdom != 'None':
                target_input = target_input.cuda()
            if opt.distill in ['crd']:
                contrast_idx = contrast_idx.cuda()

        # ===================forward=====================
        preact = False
        if opt.distill in ['abound']:
            preact = True

        feat_s, logit_s = model_s(input, is_feat=True)  # , preact=preact)
        if opt.tgdom != 'None':
            # , preact=preact)
            feat_target, _ = model_s(target_input, is_feat=True)

        with torch.no_grad():
            feat_t, logit_t = model_t(input, is_feat=True)  # , preact=preact)
            feat_t = [f.detach() for f in feat_t]

        # cls + kl div
        loss_cls = criterion_cls(logit_s, target)
        loss_div = criterion_div(logit_s, logit_t)

        # print(logit_s,logit_t)  #32x2
        # print(loss_cls)

        # other kd beyond KL divergence
        if opt.distill == 'kd':
            loss_kd = 0
        elif opt.distill == 'hint':
            f_s = module_list[1](feat_s[opt.hint_layer])
            f_t = feat_t[opt.hint_layer]
            loss_kd = criterion_kd(f_s, f_t)
        elif opt.distill == 'crd':
            f_s = feat_s[-1]
            f_t = feat_t[-1]
            loss_kd = criterion_kd(f_s, f_t, index, contrast_idx)
            # print('contrast id: ', contrast_idx)
        elif opt.distill == 'attention':
            g_s = feat_s[1:-1]
            g_t = feat_t[1:-1]
            loss_group = criterion_kd(g_s, g_t)
            loss_kd = sum(loss_group)
        elif opt.distill == 'nst':
            g_s = feat_s[1:-1]
            g_t = feat_t[1:-1]
            loss_group = criterion_kd(g_s, g_t)
            loss_kd = sum(loss_group)
        elif opt.distill == 'similarity':
            g_s = [feat_s[-2]]
            g_t = [feat_t[-2]]
            loss_group = criterion_kd(g_s, g_t)
            loss_kd = sum(loss_group)
        elif opt.distill == 'rkd':
            f_s = feat_s[-1]
            f_t = feat_t[-1]
            loss_kd = criterion_kd(f_s, f_t)
        elif opt.distill == 'pkt':
            f_s = feat_s[-1]
            f_t = feat_t[-1]
            loss_kd = criterion_kd(f_s, f_t)
        elif opt.distill == 'kdsvd':
            g_s = feat_s[1:-1]
            g_t = feat_t[1:-1]
            loss_group = criterion_kd(g_s, g_t)
            loss_kd = sum(loss_group)
        elif opt.distill == 'correlation':
            f_s = module_list[1](feat_s[-1])
            f_t = module_list[2](feat_t[-1])
            loss_kd = criterion_kd(f_s, f_t)
        elif opt.distill == 'vid':
            g_s = feat_s[1:-1]
            g_t = feat_t[1:-1]
            loss_group = [c(f_s, f_t)
                          for f_s, f_t, c in zip(g_s, g_t, criterion_kd)]
            loss_kd = sum(loss_group)
        elif opt.distill == 'abound':
            # can also add loss to this stage
            loss_kd = 0
        elif opt.distill == 'fsp':
            # can also add loss to this stage
            loss_kd = 0
        elif opt.distill == 'factor':
            factor_s = module_list[1](feat_s[-2])
            factor_t = module_list[2](feat_t[-2], is_factor=True)
            loss_kd = criterion_kd(factor_s, factor_t)
        else:
            raise NotImplementedError(opt.distill)

        if opt.tgdom != 'None':
            p = float(idx + epoch*len_source_loader) / len_source_loader / opt.epochs
            alpha = (2. / (1. + np.exp(-10*p))) - 1

            feat_source = feat_s[-1]
            feat_tgt = feat_target[-1]
            loss_dom_source, loss_dom_target = critetion_dom(
                feat_source, feat_tgt, alpha)
        else:
            loss_dom_source, loss_dom_target = 0, 0

        loss = opt.gamma * loss_cls + opt.alpha * loss_div + opt.beta * loss_kd + \
            (opt.tgdom != 'None') * opt.theta * \
            (loss_dom_source + loss_dom_target)

        acc1 = accuracy(logit_s, target)
        f1Score = f1(logit_s, target)   # scala
        losses.update(loss.item(), input.size(0))
        top1.update(acc1[0], input.size(0))
        F1Score.update(f1Score, input.size(0))
        if opt.tgdom != 'None':
            source_dom_loss.update(loss_dom_source.item(), input.size(0))
            target_dom_loss.update(loss_dom_target.item(), input.size(0))

        # ===================backward=====================
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # ===================meters=====================
        batch_time.update(time.time() - end)
        end = time.time()

        # print info
        if idx % opt.print_freq == 0:
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Acc@1 {top1.val:.3f} ({top1.avg:.3f})\t'
                  'F1 Score {F1Score.val:.3f} ({F1Score.avg:.3f})'
                  .format(
                      epoch, idx, len_source_loader, batch_time=batch_time,
                      data_time=data_time, loss=losses, top1=top1, F1Score=F1Score))
            sys.stdout.flush()

        idx += 1

    print(' * Acc@1 {top1.avg:.3f}\t'
          'F1 Score {F1Score.avg:.3f}'
          .format(top1=top1, F1Score=F1Score))

    if opt.tgdom != 'None':
        return top1.avg, losses.avg, F1Score.avg, source_dom_loss.avg, target_dom_loss.avg
    else:
        return top1.avg, losses.avg, F1Score.avg


def validate(val_loader, model, criterion, opt):
    """validation"""
    batch_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()

    # switch to evaluate mode
    model.eval()
    output_list, target_list = torch.empty(0, opt.classes), torch.empty(0)
    with torch.no_grad():
        end = time.time()
        for idx, (input, target) in enumerate(val_loader):

            input = input.float()
            target_f = target.float()

            if torch.cuda.is_available():
                input = input.cuda()
                target = target.cuda()
                target_f = target_f.cuda()
                output_list = output_list.cuda()
                target_list = target_list.cuda()

            target_list = torch.cat((target_list, target_f))
            # compute output
            output = model(input)  # (16,2)
            # output = torch.squeeze(output)
            # print(output_list.shape, output.shape)
            output_list = torch.cat((output_list, output))

            loss = criterion(output, target)

            # measure accuracy and record loss
            # for cifar
            # acc1, acc5 = accuracy(output, target, topk=(1, 5))

            # for covidCT
            acc1 = accuracy(output, target)

            losses.update(loss.item(), input.size(0))
            top1.update(acc1[0], input.size(0))

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            if idx % opt.print_freq == 0:
                print('Test: [{0}/{1}]\t'
                      'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                      'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                      'Acc@1 {top1.val:.3f} ({top1.avg:.3f})\t'
                      .format(idx, len(val_loader), batch_time=batch_time, loss=losses,
                              top1=top1))

        f1Score = f1(output_list, target_list)
        pred = output_list[:, 1]

        # print(output_list, temp)
        if opt.classes == 2:
            fpr, tpr, thresh = roc_curve(
                target_list.view(-1).cpu(), pred.view(-1).cpu())
            auc1 = auc(fpr, tpr)
            auc2 = roc_auc_score(target_list.view(-1).cpu(),
                                 pred.view(-1).cpu(), average='weighted')
        else:
            auc1 = 0

        print(' * Acc@1 {top1.avg:.6f}\t'
              .format(top1=top1))

    return top1.avg, losses.avg, f1Score, auc1  # , auc2
