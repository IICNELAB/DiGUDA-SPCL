
import os
from Config_TSNE import *
import torch
import torch.nn.functional as F
from dataset.office import get_office31_dataloaders_sample, office31_target_domain_trainloaders
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from models.ResNet import ResNet50
import argparse


def parse_option():
    parser = argparse.ArgumentParser('argument for training')
    parser.add_argument('--classes', type=int, default=31,
                        help='number of classes')
    parser.add_argument('--dataset_path', type=str,
                        default='./Office31data', help='dataset path')
    parser.add_argument('--print_freq', type=int,
                        default=40, help='print frequency')
    parser.add_argument('--tb_freq', type=int,
                        default=500, help='tb frequency')
    parser.add_argument('--save_freq', type=int,
                        default=40, help='save frequency')
    parser.add_argument('--batch_size', type=int,
                        default=450, help='batch_size')
    parser.add_argument('--num_workers', type=int,
                        default=1, help='num of workers to use')
    parser.add_argument('--epochs', type=int, default=20,
                        help='number of training epochs')
    parser.add_argument('--init_epochs', type=int, default=30,
                        help='init training for two-stage methods')

    # optimization
    parser.add_argument('--learning_rate', type=float,
                        default=1e-2, help='learning rate')
    # parser.add_argument('--lr_decay_epochs', type=str,
    #                     default='130,155,180', help='where to decay lr, can be a list')
    parser.add_argument('--lr_sttg', type=str, default='grl',
                        choices=['grl', 'cos', 'epoch_dec'], help='learning rate adjust strategy')
    # parser.add_argument('--lr_decay_rate', type=float,
    #                     default=0.1, help='decay rate for learning rate')
    parser.add_argument('--weight_decay', type=float,
                        default=5e-4, help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.9, help='momentum')

    # dataset
    # parser.add_argument('--dataset', type=str, default='SarsCov', choices=[
    #                     'cifar100', 'covidCT', 'SarsCov', 'covidx2', 'mnist', 'mnist_m', 'mnist_2', 'amazon', 'dslr', 'webcam'], help='dataset')
    parser.add_argument('--dataset', type=str, default="dslr", choices=[
        'mnist', 'mnist_m', 'mnist_2', 'amazon', 'dslr', 'webcam'], help='dataset')

    # model
    parser.add_argument('--model_s', type=str, default='ResNet50',
                        choices=['resnet8', 'resnet14', 'resnet20', 'resnet32', 'resnet44', 'resnet56', 'resnet110',
                                 'resnet8x4', 'resnet32x4', 'wrn_16_1', 'wrn_16_2', 'wrn_40_1', 'wrn_40_2',
                                 'vgg8', 'vgg11', 'vgg13', 'vgg13poc', 'vgg16', 'vgg19', 'ResNet50', 'ResNet34',
                                 'MobileNetV2', 'ShuffleV1', 'ShuffleV2', 'CovidNext50', 'CovidNet'])

    parser.add_argument('--path_t', type=str, default=None,
                        help='teacher model snapshot')

    # domain adaption and domain generalization
    # parser.add_argument('--tgdom', type=str, default='None', choices=['SarsCov', 'covidCT', 'covidx2', 'None',
    #                                                                   'mnist', 'mnist_m', 'mnist_2', 'amazon', 'dslr', 'webcam'], help='target domain for domain adaption or domain generalization')
    parser.add_argument('--tgdom', type=str, default='amazon', choices=['None', 'mnist', 'mnist_m', 'amazon',
                                                                        'dslr', 'webcam'], help='target domain for domain adaption or domain generalization')

    # distillation
    parser.add_argument('--distill', type=str, default='crd', choices=['kd', 'hint', 'attention', 'similarity',
                                                                       'correlation', 'vid', 'crd', 'kdsvd', 'fsp',
                                                                       'rkd', 'pkt', 'abound', 'factor', 'nst'])
    parser.add_argument('-t', '--trial', type=str,
                        default='0', help='trial id')

    parser.add_argument('-r', '--gamma', type=float,
                        default=1, help='weight for CE loss')
    parser.add_argument('-a', '--alpha', type=float,
                        default=None, help='weight balance for KD loss')
    parser.add_argument('-b', '--beta', type=float,
                        default=None, help='weight balance for contrast loss')
    parser.add_argument('-tht', '--theta', type=float,
                        default=1, help='weight balance for DANN')

    # KL distillation
    parser.add_argument('--kd_T', type=float, default=20,
                        help='temperature for KD distillation')

    # NCE distillation
    parser.add_argument('--feat_dim', default=128,
                        type=int, help='feature dimension')
    parser.add_argument('--mode', default='exact',
                        type=str, choices=['exact', 'relax'])
    parser.add_argument('--nce_k', default=128, type=int,
                        help='number of negative samples for NCE')  # 16384=2^14

    parser.add_argument('--nce_t', default=0.5, type=float,     # 0.07
                        help='temperature parameter for softmax')
    parser.add_argument('--nce_m', default=0.5, type=float,
                        help='momentum for non-parametric updates')

    opt = parser.parse_args()
    return opt


def visualize_model(model):
    model.eval()
    with torch.no_grad():
        # for data, target in target_loader:
        iter_target = iter(target_loader)
        iter_source = iter(source_loader)
        source_data, source_label, _, _ = iter_source.next()
        target_data, target_label = iter_target.next()
        # if cuda:
        target_data, target_label = target_data.cuda(), target_label.cuda()
        source_data, source_label = source_data.cuda(), source_label.cuda()
        source_feat = model(source_data, is_feat=True)[0][-1].cpu()
        # source_labels = source_label.cpu()
        target_feat = model(target_data, is_feat=True)[0][-1].cpu()
        # target_labels = target_label.cpu()
        print(source_feat.shape)
        print(target_feat.shape)

        tsne = TSNE(n_components=2, perplexity=20, init='pca', random_state=0)
        feat_all = torch.cat((source_feat, target_feat), dim=0)
        # print(feat_all.shape)
        f_all = tsne.fit_transform(feat_all)
        s_f, t_f = np.array_split(f_all, 2, axis=0)
        # print(s_f.shape)
        # print(t_f.shape)

        sx_min, sx_max = np.min(s_f, 0), np.max(s_f, 0)
        tx_min, tx_max = np.min(t_f, 0), np.max(t_f, 0)
        data_s = (s_f - sx_min) / (sx_max - sx_min)     # feature normailize
        data_t = (t_f - tx_min) / (tx_max - tx_min)
        del s_f, t_f

        plt.scatter(data_s[:, 0], data_s[:, 1], s=10, c='b', marker='.')
        plt.scatter(data_t[:, 0], data_t[:, 1], s=10, c='r', marker='.')
        plt.xticks([])
        plt.yticks([])
        # plt.title('T-SNE')
        plt.savefig('tsne1.png')
        plt.show()

    return


if __name__ == '__main__':
    # kwargs = {'num_workers': 8, 'pin_memory': True}

    # len_target_dataset = len(target_loader.dataset)
    # print(len_target_dataset)

    # =========== DiG-UDA ========================
    opt = parse_option()
    print(source_name+'->'+target_name)
    source_loader, _, _, _ = get_office31_dataloaders_sample(opt, batch_size=opt.batch_size,
                                                             num_workers=8,
                                                             k=128,
                                                             samplemode="exact")

    target_loader, _ = office31_target_domain_trainloaders(opt, target_name)
    '''visualize DiG-UDA model'''
    model = ResNet50(num_classes=31).cuda()
    model.load_state_dict(torch.load(diguda_path)['model'])
    visualize_model(model)
