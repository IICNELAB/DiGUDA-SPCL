"""
the test framework
"""

from __future__ import print_function

import os
import argparse

import tensorboard_logger as tb_logger
import torch
import torch.optim as optim
import torch.nn as nn
import torch.backends.cudnn as cudnn

from models import model_dict
# from models.util import Embed, ConvReg, LinearEmbed
# from models.util import Connector, Translator, Paraphraser

# from dataset.cifar100 import get_cifar100_dataloaders, get_cifar100_dataloaders_sample
# from dataset.covidCT import get_covidCT_dataloaders, get_covidCT_dataloaders_sample
from dataset.mnist import getMnist
from dataset.office import load_training, load_testing, get_office31_dataloaders_sample


# from distiller_zoo import DistillKL, HintLoss, Attention, Similarity, Correlation, VIDLoss, RKDLoss
# from distiller_zoo import PKT, ABLoss, FactorTransfer, KDSVD, FSP, NSTLoss
# from crd.criterion import CRDLoss
# from da.criterion import DomLoss

from helper.loops import validate


def parse_option():

    parser = argparse.ArgumentParser('argument for test')

    parser.add_argument('--classes', type=int, default=31, help='number of classes')
    parser.add_argument('--dataset_path', type=str, default='./Office31data', help='dataset path')
    parser.add_argument('--batch_size', type=int, default=32, help='batch_size')
    parser.add_argument('--num_workers', type=int, default=8, help='num of workers to use')
    # parser.add_argument('--epochs', type=int, default=200, help='number of training epochs')
    parser.add_argument('--print_freq', type=int, default=40, help='print frequency')

    parser.add_argument('--distill', type=str, default='crd', choices=['kd', 'hint', 'attention', 'similarity',
                                                                       'correlation', 'vid', 'crd', 'kdsvd', 'fsp',
                                                                       'rkd', 'pkt', 'abound', 'factor', 'nst'])
    parser.add_argument('--nce_k', default=128, type=int, help='number of negative samples for NCE')  # 16384=2^14
    parser.add_argument('--mode', default='exact', type=str, choices=['exact', 'relax'])

    # dataset
    parser.add_argument('--dataset', type=str, default='amazon', choices=['mnist', 'mnist_m', 'amazon', 'dslr', 'webcam'], help='dataset')
    parser.add_argument('--tgdom', type=str, default='None', choices=['None', 'mnist', 'mnist_m', 'amazon',
                                                                      'dslr', 'webcam'], help='target domain for domain adaption or domain generalization')

    # model
    parser.add_argument('--path_t', type=str, default=None, help='model snapshot')

    opt = parser.parse_args()

    opt.model_t = get_model_name(opt.path_t)

    return opt


def get_model_name(model_path):
    """parse model name"""
    segments = model_path.split('/')[-2].split('_')
    if segments[0] != 'wrn':
        return segments[0]
    else:
        return segments[0] + '_' + segments[1] + '_' + segments[2]


def load_model(model_path, n_cls):
    print('==> loading model')

    model_t = get_model_name(model_path)
    model = model_dict[model_t](num_classes=n_cls)
    model.load_state_dict(torch.load(model_path)['model'])

    print('==> done')
    return model


def main():
    opt = parse_option()

    # dataloader
    # if opt.dataset == 'cifar100':
    #     if opt.distill in ['crd']:
    #         _, val_loader, n_data = get_cifar100_dataloaders_sample(batch_size=opt.batch_size,
    #                                                                 num_workers=opt.num_workers,
    #                                                                 k=opt.nce_k,
    #                                                                 mode=opt.mode)
    #     else:
    #         _, val_loader, n_data = get_cifar100_dataloaders(batch_size=opt.batch_size,
    #                                                          num_workers=opt.num_workers,
    #                                                          is_instance=True)
    #     n_cls = opt.classes
    # elif opt.dataset in ['covidCT', 'SarsCov', 'covidx2']:
    #     if opt.distill in ['crd']:
    #         _, val_loader, _, test_n_data = get_covidCT_dataloaders_sample(opt, batch_size=opt.batch_size,
    #                                                                        num_workers=opt.num_workers,
    #                                                                        k=opt.nce_k,
    #                                                                        samplemode=opt.mode)
    #         # print('n_data: ', n_data)
    #     else:
    #         _, val_loader, _, test_n_data = get_covidCT_dataloaders(opt, is_instance=True)

    #     n_cls = 2
    if opt.dataset in ['mnist', 'mnist_m']:
        _, val_loader, _, test_n_data = getMnist(deform=opt.dataset)
        n_cls = 10
        opt.classes = 10
    elif opt.dataset in ['amazon', 'dslr', 'webcam']:
        n_cls = 31

        # root_path = "../DatasetCollection/office31/"
        # domain_name = opt.dataset
        # kwargs = {'num_workers': opt.num_workers, 'pin_memory': True}
        # val_loader, _ = load_testing(root_path, domain_name, opt.batch_size, kwargs)
        _, val_loader, _, _ = get_office31_dataloaders_sample(opt, opt.batch_size)

    else:
        raise NotImplementedError(opt.dataset)

    # model
    model_t = load_model(opt.path_t, n_cls)

    # data = torch.randn(2, 3, 224, 224)
    model_t.eval()
    criterion = nn.CrossEntropyLoss()

    if torch.cuda.is_available():
        model_t.cuda()
        criterion.cuda()
        cudnn.benchmark = True

    # validate model
    model_acc, _, model_F1, model_aucc = validate(val_loader, model_t, criterion, opt)
    print('Test accuracy: ', model_acc, '\tmodel F1 score: ', model_F1,  '\tmodel aucc score: ', model_aucc)


if __name__ == '__main__':
    main()
