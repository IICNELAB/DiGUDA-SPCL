# %%

from __future__ import print_function

import os
import socket
import numpy as np
import pydicom
import matplotlib.pyplot as plt

from PIL import Image
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# from utils import RGB2L, RGB2ab

# %%

"""
plot med dicom images
"""

fname='/home/mori/Desktop/ICDC-Glioma/GLIOMA01-i_D7EC/11-08-2012-BRAIN-60390/3.000000-TSE 15135  TRANS-69306/1-14.dcm'    

ds=pydicom.dcmread(fname)
# print(ds.pixel_array.shape)
print(ds.pixel_array[1])
plt.figure()
plt.imshow(ds.pixel_array, cmap='gray')
plt.axis('off')
plt.show()

# %%


def get_data_folder():
    """
    return server-dependent path to store the data
    """
    data_folder = './MedData/'

    if not os.path.isdir(data_folder):
        os.makedirs(data_folder)

    return data_folder
    
    
