
import os
import socket
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.utils.data.dataset import Dataset
from torchvision import datasets, transforms
from torchvision.datasets import DatasetFolder
from torch.utils.data.sampler import RandomSampler
from PIL import Image


def load_training(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([256, 256]),
         transforms.RandomCrop(224),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor()])
    data = datasets.ImageFolder(root=root_path + dir, transform=transform)
    n_data = len(data)
    train_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, drop_last=True, **kwargs)
    return train_loader, n_data


def load_testing(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([224, 224]),
         transforms.ToTensor()])
    data = datasets.ImageFolder(root=root_path + dir, transform=transform)
    n_data = len(data)
    test_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, **kwargs)
    return test_loader, n_data


#  ================ sample Office for crd ========================
#  todo

def read_office_filepaths(file):
    paths, labels = [], []
    with open(file, 'r') as f:
        lines = f.read().splitlines()

        for _, line in enumerate(lines):
            if '/ c o' in line:
                break
            try:
                path, label = line.split(' ')
            except:
                print(line)

            paths.append(path)
            labels.append(label)
    return paths, labels


class Office31_Dataset(Dataset):
    """
    Code for reading the Office31 dataset
    """

    def __init__(self, args, mode, n_classes=31, dataset_path='./Office31data', dim=(224, 224), target_domain=None):
        self.mode = mode
        self.CLASSES = n_classes
        self.dim = dim
        self.OfficexDICT = {'bike_helmet': 0, 'ring_binder': 1, 'back_pack': 2, 'phone': 3, 'pen': 4, 'tape_dispenser': 5, 'bottle': 6, 'file_cabinet': 7, 'trash_can': 8, 'letter_tray': 9, 'printer': 10, 'desk_chair': 11, 'headphones': 12, 'mouse': 13, 'keyboard': 14,
                            'bookcase': 15, 'desktop_computer': 16, 'monitor': 17, 'scissors': 18, 'speaker': 19, 'stapler': 20, 'paper_notebook': 21, 'projector': 22, 'calculator': 23, 'bike': 24, 'ruler': 25, 'mobile_phone': 26, 'mug': 27, 'laptop_computer': 28, 'punchers': 29, 'desk_lamp': 30}
        # self.doDA = not (target_domain == None)

        if mode == 'train':
            # print(args.dataset)
            if args.dataset == "amazon":
                trainfile = "/home/mori/Programming/MedConDistill/Office31data/amazon/train.txt"
            elif args.dataset == "dslr":
                trainfile = "/home/mori/Programming/MedConDistill/Office31data/dslr/train.txt"
            elif args.dataset == 'webcam':
                trainfile = "/home/mori/Programming/MedConDistill/Office31data/webcam/train.txt"

            self.paths, self.labels = read_office_filepaths(trainfile)
            self.trainpaths, self.trainlabels = self.paths, self.labels

        elif mode == 'test':
            if args.dataset == "amazon":
                testfile = "/home/mori/Programming/MedConDistill/Office31data/amazon/test.txt"
            elif args.dataset == "dslr":
                testfile = "/home/mori/Programming/MedConDistill/Office31data/dslr/test.txt"
            elif args.dataset == 'webcam':
                testfile = "/home/mori/Programming/MedConDistill/Office31data/webcam/test.txt"

            self.paths, self.labels = read_office_filepaths(testfile)
            self.testpaths, self.testlabels = self.paths, self.labels

        print("{} {} examples =  {}".format(args.dataset, mode, len(self.paths)))
        # target_domain = args.tgdom
        # if target_domain != None:
        #     print("Target domain: {} {} examples =  {}".format(
        #         target_domain, mode, len(self.paths)))

        self.mode = mode

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, index):
        image_tensor = self.load_image(self.paths[index])
        label_tensor = torch.tensor(
            self.OfficexDICT[self.labels[index]], dtype=torch.long)

        return image_tensor, label_tensor

    def load_image(self, img_path):
        if not os.path.exists(img_path):
            print("IMAGE DOES NOT EXIST {}".format(img_path))

        image = Image.open(img_path).convert('RGB')

        transform = {
            'train': transforms.Compose(
                [transforms.Resize([256, 256]),
                 transforms.RandomCrop(224),
                 transforms.RandomHorizontalFlip()]),
            'test': transforms.Compose(
                [transforms.Resize([224, 224])])}

        transformtotensor = transforms.Compose(
            [transforms.ToTensor()])
        #  transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])

        if self.mode == 'train':
            image = transform['train'](image)
        else:
            image = transform['test'](image)

        image_tensor = transformtotensor(image)

        return image_tensor


class Office31instanceSample(Office31_Dataset):
    """
    Office31 Instance+Sample Dataset
    """

    def __init__(self, args, mode, n_classes=31, dataset_path='./Office31data',
                 k=32, samplemode='exact', is_sample=True, percent=1.0, dim=(224, 224)):
        super().__init__(args, mode, n_classes=31,
                         dataset_path='./Office31data', dim=(224, 224))

        self.k = k
        self.samplemode = samplemode
        self.is_sample = is_sample

        num_classes = 31

        if self.mode == 'train':
            num_samples = len(self.trainpaths)
            label = self.trainlabels
        else:
            num_samples = len(self.testpaths)
            label = self.testlabels

        self.cls_positive = [[] for i in range(num_classes)]
        for i in range(num_samples):
            self.cls_positive[self.OfficexDICT[label[i]]].append(i)

        self.cls_negative = [[] for i in range(num_classes)]
        for i in range(num_classes):
            for j in range(num_classes):
                if j == i:
                    continue
                self.cls_negative[i].extend(self.cls_positive[j])

        self.cls_positive = [np.asarray(self.cls_positive[i])
                             for i in range(num_classes)]
        self.cls_negative = [np.asarray(self.cls_negative[i])
                             for i in range(num_classes)]

        if 0 < percent < 1:
            n = int(len(self.cls_negative[0]) * percent)
            self.cls_negative = [np.random.permutation(self.cls_negative[i])[0:n]
                                 for i in range(num_classes)]

        self.cls_positive = np.asarray(self.cls_positive)
        self.cls_negative = np.asarray(self.cls_negative)

    def load_image(self, img_path):
        image_tensor = super().load_image(img_path)
        return image_tensor

    def __getitem__(self, index):
        img, target = super().__getitem__(index)

        if not self.is_sample:
            # directly return
            return img, target, index
        else:
            # sample contrastive examples
            if self.samplemode == 'exact':
                pos_idx = index
            elif self.samplemode == 'relax':
                pos_idx = np.random.choice(self.cls_positive[target], 1)
                pos_idx = pos_idx[0]
            else:
                raise NotImplementedError(self.samplemode)
            replace = True if self.k > len(
                self.cls_negative[target]) else False
            neg_idx = np.random.choice(
                self.cls_negative[target], self.k, replace=replace)
            sample_idx = np.hstack((np.asarray([pos_idx]), neg_idx))
            return img, target, index, sample_idx


class Office31_target_Dataset(Dataset):
    """
    Code for reading the target Office31 dataset
    """

    def __init__(self, args, mode, n_classes=31, dataset_path='./Office31data', dim=(224, 224), target_domain=None):
        self.mode = mode
        self.CLASSES = n_classes
        self.dim = dim
        self.OfficexDICT = {'back_pack': 0, 'bike': 1, 'bike_helmet': 2, 'bookcase': 3, 'bottle': 4, 'calculator': 5, 'desk_chair': 6,
                            'desk_lamp': 7, 'desktop_computer': 8, 'file_cabinet': 9, 'headphones': 10, 'keyboard': 11, 'laptop_computer': 12, 'letter_tray': 13,
                            'mobile_phone': 14, 'monitor': 15, 'mouse': 16, 'mug': 17, 'paper_notebook': 18, 'pen': 19, 'phone': 20, 'printer': 21, 'projector': 22,
                            'punchers': 23, 'ring_binder': 24, 'ruler': 25, 'scissors': 26, 'speaker': 27, 'stapler': 28, 'tape_dispenser': 29, 'trash_can': 30}

        if args.tgdom == "amazon":
            trainfile = "/home/mori/Programming/MedConDistill/Office31data/amazon/train.txt"
        elif args.tgdom == "dslr":
            trainfile = "/home/mori/Programming/MedConDistill/Office31data/dslr/train.txt"
        elif args.tgdom == "webcam":
            trainfile = "/home/mori/Programming/MedConDistill/Office31data/webcam/train.txt"

        self.paths, self.labels = read_office_filepaths(trainfile)
        self.trainpaths, self.trainlabels = self.paths, self.labels

        target_domain = args.tgdom
        print("Target domain: {} {} examples =  {}".format(
            target_domain, mode, len(self.paths)))

        self.mode = mode

    def __len__(self):
        return len(self.trainpaths)

    def __getitem__(self, index):
        image_tensor = self.load_image(self.paths[index])
        label_tensor = torch.tensor(
            self.OfficexDICT[self.labels[index]], dtype=torch.long)

        return image_tensor, label_tensor

    def load_image(self, img_path):
        if not os.path.exists(img_path):
            print("IMAGE DOES NOT EXIST {}".format(img_path))

        image = Image.open(img_path).convert('RGB')

        transform = {
            'train': transforms.Compose(
                [transforms.Resize([256, 256]),
                 transforms.RandomCrop(224),
                 transforms.RandomHorizontalFlip()]),
            'test': transforms.Compose(
                [transforms.Resize([256, 256]),
                 transforms.CenterCrop(224)])
        }

        transformtotensor = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])

        if self.mode == 'train':
            image = transform['train'](image)
        else:
            image = transform['test'](image)

        image_tensor = transformtotensor(image)

        return image_tensor


def get_office31_dataloaders_sample(args, batch_size, num_workers=8, k=32, samplemode='exact',
                                    is_sample=True, percent=1.0):
    """
    Office31
    for student distill
    """
    train_loader = Office31instanceSample(args,
                                          k=k,
                                          mode='train',
                                          samplemode=samplemode,
                                          is_sample=is_sample,
                                          percent=percent)
    train_n_data = len(train_loader)

    train_generator = DataLoader(train_loader,
                                 batch_size=batch_size,
                                 shuffle=True,
                                 num_workers=num_workers)

    test_loader = Office31_Dataset(args,
                                   mode='test',
                                   n_classes=args.classes,
                                   dataset_path=args.dataset_path,
                                   dim=(224, 224))
    test_n_data = len(test_loader)

    # tsampler = RandomSampler(test_loader)
    test_generator = DataLoader(test_loader,
                                batch_size=int(batch_size),
                                shuffle=False,
                                # sampler=tsampler,
                                num_workers=int(num_workers))

    return train_generator, test_generator, train_n_data, test_n_data


'''for DA: target dataloader'''


def office31_target_domain_trainloaders(args, target_domain):

    train_loader = Office31_target_Dataset(args,
                                           mode='train',
                                           n_classes=args.classes,
                                           dataset_path=args.dataset_path,
                                           dim=(224, 224))
    n_data = len(train_loader)
    training_generator = DataLoader(train_loader,
                                    batch_size=args.batch_size,
                                    shuffle=False,
                                    num_workers=8)

    return training_generator, n_data


# if __name__ == '__main__':
#     file = "/home/mori/Programming/MedConDistill/Office31data/amazon/train.txt"
#     print(read_office_filepaths(file))
