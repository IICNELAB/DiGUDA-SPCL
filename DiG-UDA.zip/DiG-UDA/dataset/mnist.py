import os
import numpy as np
import torch
import torchvision
from torchvision import datasets, transforms
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from torchvision.transforms.transforms import RandomCrop, RandomHorizontalFlip, RandomRotation, RandomVerticalFlip, Resize

# mnist


def getMnist(deform='mnist'):
    if deform == 'mnist_m':
        transform = transforms.Compose([
            transforms.RandomRotation((0, 60), fill=(0,)),
            transforms.RandomHorizontalFlip(p=0.8),
            transforms.ToTensor(),
            transforms.Lambda(lambda x: x.repeat(3, 1, 1)),
            transforms.Normalize(mean=[0.4, 0.4, 0.4], std=[0.2, 0.2, 0.2])])

    elif deform == 'mnist_2':
        transform = transforms.Compose([
            transforms.RandomRotation((0, 20), fill=(0,)),
            transforms.RandomHorizontalFlip(p=0.2),
            transforms.ToTensor(),
            transforms.Lambda(lambda x: x.repeat(3, 1, 1)),
            transforms.Normalize(mean=[0.4, 0.4, 0.4], std=[0.2, 0.2, 0.2])])
    else:
        transform = transforms.Compose([
            transforms.ToTensor(),
            # transforms.Normalize(mean=(0.1307,), std=(0.3081,))])
            transforms.Lambda(lambda x: x.repeat(3, 1, 1)),
            transforms.Normalize(mean=[0.4, 0.4, 0.4], std=[0.2, 0.2, 0.2])])

    data_train = datasets.MNIST(root='./data/',
                                train=True,
                                transform=transform,
                                download=False)
    train_n_data = len(data_train)        # 60k

    data_test = datasets.MNIST(root='./data/',
                               train=False,
                               transform=transform)
    test_n_data = len(data_test)

    train_generator = DataLoader(dataset=data_train,
                                 batch_size=400,
                                 shuffle=True)

    test_generator = DataLoader(dataset=data_test,
                                batch_size=400,
                                shuffle=False)

    return train_generator, test_generator, train_n_data, test_n_data


if __name__ == '__main__':
    mn_train, mn_test, _, _ = getMnist(deform='mnist')
    examples = enumerate(mn_train)
    batch_idx, (data, target) = next(examples)
    # print(data.shape)

    fig = plt.figure()

    # for i in range(6):
    #     plt.subplot(2,3,i+1)
    #     plt.savefig('/home/mori/Desktop/new.jpg')
    #     plt.tight_layout()
    #     plt.imshow(data[i][0])

    for i in range(600):
        if target[i] == 3:
            print(i)
            plt.imshow(data[i][0], cmap='gray')
            plt.axis('off')
            plt.savefig('/home/mori/Desktop/3/new'+str(i)+'.jpg', bbox_inches='tight', dpi=200, pad_inches=0.0)  # 适合导入Latex
            # plt.pause(1)
