# import collections
import os
# import pprint
import numpy as np
# import pandas as pd
import torch
from PIL import Image
from skimage.io import imread
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import RandomSampler
from torchvision import transforms
# from skimage.segmentation import slic, mark_boundaries
import cv2
from helper.util import read_filepaths, read_filepaths2


class COVID_CT_Dataset(Dataset):
    """
    Code for reading the COVIDxDataset
    """

    def __init__(self, args, mode, n_classes=2, dataset_path='./MedData/data', dim=(224, 224), target_domain=None):
        self.mode = mode
        self.CLASSES = n_classes
        self.dim = dim
        self.COVIDxDICT = {'normal': 0, 'COVID-19': 1}
        self.doDA = not (target_domain == None)

        trainfile = os.path.join(dataset_path, 'COVID-CT', 'train_split.txt')
        testfile = os.path.join(dataset_path, 'COVID-CT', 'test_split.txt')
        newtrainpath, newtrainlabel = read_filepaths2(
            './MedData/data/SARS-Cov-2/train_split.txt')
        newtestpath, newtestlabel = read_filepaths2(
            './MedData/data/SARS-Cov-2/test_split.txt')

        if mode == 'train':
            # covidCT
            if (target_domain == None and args.dataset == 'covidCT') or target_domain == 'covidCT':
                # covidCT training dataset is enlarged to 2172 images...(by extend)
                self.paths, self.labels = read_filepaths(trainfile, self.mode)
                self.paths.extend(self.paths)
                self.labels.extend(self.labels)
                self.paths.extend(self.paths)
                self.labels.extend(self.labels)
                if args.dataset == 'covidx2':  # to make target domain and source domain dataset size similar
                    self.paths.extend(self.paths)
                    self.labels.extend(self.labels)

                self.trainpaths, self.trainlabels = self.paths, self.labels
            # SARS-CoV
            elif (target_domain == None and args.dataset == 'SarsCov') or target_domain == 'SarsCov':
                self.paths, self.labels = newtrainpath, newtrainlabel
                if args.dataset == 'covidx2':
                    self.paths.extend(self.paths)
                    self.labels.extend(self.labels)

                self.trainpaths, self.trainlabels = self.paths, self.labels
            # SARS-CoV + CovidCT
            elif (target_domain == None and args.dataset == 'covidx2') or target_domain == 'covidx2':
                self.paths, self.labels = read_filepaths(trainfile, self.mode)
                self.paths.extend(self.paths)
                self.labels.extend(self.labels)
                self.paths.extend(self.paths)
                self.labels.extend(self.labels)

                self.paths.extend(newtrainpath)
                self.labels.extend(newtrainlabel)

                self.trainpaths, self.trainlabels = self.paths, self.labels
            else:
                print("Invalid Trainset!")

        elif mode == 'test':
            if args.dataset == 'covidCT':
                self.paths, self.labels = read_filepaths(testfile, self.mode)
                self.testpaths, self.testlabels = self.paths, self.labels

            elif args.dataset == 'SarsCov':
                self.paths, self.labels = newtestpath, newtestlabel
                self.testpaths, self.testlabels = self.paths, self.labels

            elif args.dataset == 'covidx2':
                self.paths, self.labels = read_filepaths(testfile, self.mode)
                self.paths.extend(newtestpath)
                self.labels.extend(newtestlabel)

                self.testpaths, self.testlabels = self.paths, self.labels
            else:
                print("Invalid Testset!")

        if target_domain == None:
            print("{} examples =  {}".format(mode, len(self.paths)))
        else:
            print("Target domain: {} {} examples =  {}".format(
                target_domain, mode, len(self.paths)))

        self.mode = mode

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, index):
        image_tensor = self.load_image(self.paths[index])
        label_tensor = torch.tensor(
            self.COVIDxDICT[self.labels[index]], dtype=torch.long)

        return image_tensor, label_tensor  # , site

    def load_image(self, img_path):
        if not os.path.exists(img_path):
            print("IMAGE DOES NOT EXIST {}".format(img_path))

        # if img_path.split('/')[3] == 'COVID-CT':
        #     site = 'ucsd'
        # else:
        #     site = 'new'

        image = Image.open(img_path).convert('RGB')

        inputsize = 224
        transform = {
            'train': transforms.Compose(
                [transforms.Resize(256),
                 transforms.RandomCrop(224),
                 transforms.RandomHorizontalFlip(),
                 transforms.RandomVerticalFlip(),
                 ]),
            'test': transforms.Compose(
                [transforms.Resize([inputsize, inputsize]),
                 ])
        }

        transformtotensor = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

        # mean shift according to DANN
        target_domain_transform = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])])

        if self.mode == 'train':
            image = transform['train'](image)
        else:
            image = transform['test'](image)

        if self.doDA:
            # target_domain_transform(image)
            image_tensor = transformtotensor(image)
        else:
            image_tensor = transformtotensor(image)

        return image_tensor         # site


class covidCTinstance(COVID_CT_Dataset):
    def __getitem__(self, index):
        image_tensor = self.load_image(self.paths[index])
        label_tensor = torch.tensor(
            self.COVIDxDICT[self.labels[index]], dtype=torch.long)

        return image_tensor, label_tensor, index


def get_covidCT_dataloaders(args, is_instance=False):

    if is_instance:
        train_loader = covidCTinstance(args,
                                       mode='train',
                                       n_classes=args.classes,
                                       dataset_path=args.dataset_path,
                                       dim=(224, 224))
        train_n_data = len(train_loader)

    else:
        train_loader = COVID_CT_Dataset(args,
                                        mode='train',
                                        n_classes=args.classes,
                                        dataset_path=args.dataset_path,
                                        dim=(224, 224))

    test_loader = COVID_CT_Dataset(args,
                                   mode='test',
                                   n_classes=args.classes,
                                   dataset_path=args.dataset_path,
                                   dim=(224, 224))
    test_n_data = len(test_loader)

    training_generator = DataLoader(train_loader,
                                    batch_size=args.batch_size,
                                    shuffle=True,
                                    num_workers=3)
    tsampler = RandomSampler(test_loader)
    test_generator = DataLoader(test_loader,
                                batch_size=args.batch_size,
                                shuffle=False,
                                sampler=tsampler,
                                num_workers=2)
    if not is_instance:
        return training_generator, test_generator
    else:
        return training_generator, test_generator, train_n_data, test_n_data


class covidCTinstanceSample(COVID_CT_Dataset):
    """
    CovidCTInstance+Sample Dataset
    """

    def __init__(self, args, mode, dataset_path='./MedData/data',
                 k=32, samplemode='exact', is_sample=True, percent=1.0):
        super().__init__(args, mode, n_classes=2,
                         dataset_path='./MedData/data', dim=(224, 224))

        self.k = k
        self.samplemode = samplemode
        self.is_sample = is_sample

        num_classes = args.classes

        if self.mode == 'train':
            num_samples = len(self.trainpaths)
            label = self.trainlabels
        else:
            num_samples = len(self.testpaths)
            label = self.testabels

        self.cls_positive = [[] for i in range(num_classes)]
        for i in range(num_samples):
            self.cls_positive[self.COVIDxDICT[label[i]]].append(i)

        self.cls_negative = [[] for i in range(num_classes)]
        for i in range(num_classes):
            for j in range(num_classes):
                if j == i:
                    continue
                self.cls_negative[i].extend(self.cls_positive[j])

        self.cls_positive = [np.asarray(self.cls_positive[i])
                             for i in range(num_classes)]
        self.cls_negative = [np.asarray(self.cls_negative[i])
                             for i in range(num_classes)]

        if 0 < percent < 1:
            n = int(len(self.cls_negative[0]) * percent)
            self.cls_negative = [np.random.permutation(self.cls_negative[i])[0:n]
                                 for i in range(num_classes)]

        self.cls_positive = np.asarray(self.cls_positive)
        self.cls_negative = np.asarray(self.cls_negative)

    def load_image(self, img_path):
        image_tensor = super().load_image(img_path)
        return image_tensor

    def __getitem__(self, index):
        img, target = super().__getitem__(index)

        if not self.is_sample:
            # directly return
            return img, target, index
        else:
            # sample contrastive examples
            if self.samplemode == 'exact':
                pos_idx = index
            elif self.samplemode == 'relax':
                pos_idx = np.random.choice(self.cls_positive[target], 1)
                pos_idx = pos_idx[0]
            else:
                raise NotImplementedError(self.samplemode)
            replace = True if self.k > len(
                self.cls_negative[target]) else False
            neg_idx = np.random.choice(
                self.cls_negative[target], self.k, replace=replace)
            sample_idx = np.hstack((np.asarray([pos_idx]), neg_idx))
            return img, target, index, sample_idx


def get_covidCT_dataloaders_sample(args, batch_size=16, num_workers=8, k=32, samplemode='exact',
                                   is_sample=True, percent=1.0):
    """
    covidCT
    for student distill 
    """
    train_loader = covidCTinstanceSample(args,
                                         k=k,
                                         mode='train',
                                         samplemode=samplemode,
                                         is_sample=is_sample,
                                         percent=percent)
    train_n_data = len(train_loader)

    train_generator = DataLoader(train_loader,
                                 batch_size=batch_size,
                                 shuffle=True,
                                 num_workers=num_workers)

    test_loader = COVID_CT_Dataset(args,
                                   mode='test',
                                   n_classes=args.classes,
                                   dataset_path=args.dataset_path,
                                   dim=(224, 224))
    test_n_data = len(test_loader)

    tsampler = RandomSampler(test_loader)
    test_generator = DataLoader(test_loader,
                                batch_size=int(batch_size/2),
                                shuffle=False,
                                sampler=tsampler,
                                num_workers=int(num_workers/2))

    return train_generator, test_generator, train_n_data, test_n_data


'''for DA: target dataloader'''


def target_domain_trainloaders(args, target_domain):

    train_loader = COVID_CT_Dataset(args,
                                    mode='train',
                                    n_classes=args.classes,
                                    dataset_path=args.dataset_path,
                                    dim=(224, 224),
                                    target_domain=target_domain)
    n_data = len(train_loader)
    training_generator = DataLoader(train_loader,
                                    batch_size=args.batch_size,
                                    shuffle=True,
                                    num_workers=3)

    return training_generator, n_data


# if __name__ == '__main__':
#     print('hello')
