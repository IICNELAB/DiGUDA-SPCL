# %%
import PIL
import os
import argparse
from captum.attr._utils.attribution import LayerAttribution

import numpy as np
import torch
import torch.nn as nn
from models import model_dict
import matplotlib.pyplot as plt
from PIL import Image
from torchvision import transforms
import cv2

from captum.attr import (
    GradientShap,
    DeepLift,
    DeepLiftShap,
    LayerConductance,
    NeuronConductance,
    NoiseTunnel,
    LayerGradCam,
    IntegratedGradients,
)


def get_model_name(model_path):
    """parse model name"""
    segments = model_path.split('/')[-2].split('_')
    if segments[0] != 'wrn':
        return segments[0]
    else:
        return segments[0] + '_' + segments[1] + '_' + segments[2]


def load_model(model_path, n_cls):
    print('==> loading model')

    model_t = get_model_name(model_path)
    model = model_dict[model_t](num_classes=n_cls)
    model.load_state_dict(torch.load(model_path)['model'])

    print('==> done')
    return model


m_path = "/home/mori/Programming/MedConDistill/save/s_model/CovidNext50_covidx2_crd_r:1.0_a:1.0_b:0.8_C2toCCT/CovidNext50_last.pth"
model_t = load_model(m_path, n_cls=10)
model_t.eval()

# 导入模型并设置分类器

# ### 1.转换MNIST
# img = Image.open("todo。。。。").convert('L')

# transform = transforms.Compose([
#             transforms.Resize(224),
#             transforms.ToTensor(),
#             transforms.Normalize(mean=(0.1307,), std=(0.3081,))])

# img = transform(img)
# # print(img)                  # 1x224x224
# img = img.unsqueeze(0)

# 2.转换COVID
img = Image.open("/home/mori/Desktop/cct2.png") .convert('RGB')

transform = transforms.Compose([
    transforms.Resize([224, 224]),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

img_tran = transform(img)   # 3x224x224
img_tran = img_tran.unsqueeze(0)

# see model output
o = model_t(img_tran)
print(o)
###

# 梯度可视化
layer_gc = LayerGradCam(model_t, model_t.backbone_end)
attr = layer_gc.attribute(img_tran, 1, relu_attributions=True)   # 1 for covid
upsampled_attr = LayerAttribution.interpolate(attr, (224, 224))

gradimage = upsampled_attr.cpu().detach().numpy()[0]
gradimage = np.transpose(gradimage, (1, 2, 0))  # (224,224,1)


plt.imshow(gradimage)  # , cmap='')
plt.axis('off')
plt.show()


# %%
# 图片大小调整并可视化
img = Image.open("/home/mori/Desktop/cct1.png")
img = img.resize((224, 224))
# print(np.array(img).shape)
plt.imshow(img, cmap='gray')
plt.axis('off')
plt.show()


# %%
# 热力图与原图叠加

oriimage = Image.open("/home/mori/Desktop/sars2.png")
gradimage = Image.open("/home/mori/Desktop/dasgrad22.png")
oriimage = np.array(oriimage)
gradimage = np.array(gradimage)
# print(oriimage.shape)

final_img = cv2.addWeighted(oriimage, 0.3, gradimage, 0.7, 1)
plt.imshow(final_img, cmap='bone')
plt.axis('off')
plt.show()
