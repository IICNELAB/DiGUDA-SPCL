import os
import shutil


# ============================ 1. copy and rename imgs
# img_path = "/home/mori/Programming/MedConDistill/Office31data/webcam/"
# target_path = "/home/mori/Programming/MedConDistill/Office31data/train/"

# class_list = os.listdir(img_path)

# print(class_list)


# for class_name in class_list:
#     for img in os.listdir(img_path+class_name):
#         shutil.copy(img_path+class_name+'/'+img, target_path+class_name+"+"+img)
# print("done!")


# ============================= 2. create txt split file
# img_path = "/home/mori/Programming/MedConDistill/Office31data/amazon/test/"

# img_list = os.listdir(img_path)
# print(img_list)

# file = "/home/mori/Programming/MedConDistill/Office31data/amazon/test.txt"

# with open(file, 'w') as f:
#     for img in img_list:
#         class_name, _ = img.split("+")
#         f.write(img_path+img+" "+class_name+"\n")


# ==============================

img_path = "/home/mori/Programming/DatasetCollection/office31/amazon"

class_list = os.listdir(img_path)

# print(class_list)

for i in range(len(class_list)):
    print(class_list[i]+":"+str(i))
