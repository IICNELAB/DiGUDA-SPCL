
import torch.nn as nn
import torch.nn.functional as F
import math
from Config import *


class kl_div(nn.Module):
    def __init__(self, T):
        super(kl_div, self).__init__()
        self.T = T

    def forward(self, y_s, y_t):
        p_s = F.log_softmax(y_s/self.T, dim=1)
        p_t = F.softmax(y_t/self.T, dim=1)
        # not sure ..
        loss = F.kl_div(p_s, p_t, reduction='batchmean') * (self.T**2)
        return loss


def cosineAnneal(epoch):
    lr_min = 0
    new_lr = math.fabs(lr_min+(lr-lr_min) *
                       (1+math.cos(math.pi*epoch/epochs))/2.)
    return new_lr


if __name__ == '__main__':
    # import torch
    # ys = torch.tensor([[0.0868, -0.4690]])
    # yt = torch.tensor([[-1, 1]])
    # loss = kl_div(T=4)
    # print(loss(ys, yt))
    for epoch in range(10, 100):
        print(cosineAnneal(epoch))
