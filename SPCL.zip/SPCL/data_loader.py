from torchvision import transforms, datasets
import torch
from PIL import Image

# ===== DSAN style loading===============


def load_training(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([256, 256]),
         transforms.RandomCrop(224),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor()])
    data = datasets.ImageFolder(root=root_path+dir, transform=transform)
    train_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, drop_last=True, **kwargs)
    return train_loader


def load_testing(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([224, 224]),
         transforms.ToTensor()])
    data = datasets.ImageFolder(root=root_path+dir, transform=transform)
    test_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, **kwargs)
    return test_loader


# ===== CAN style loading===============

def load_training_CAN(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([256, 256], Image.BICUBIC),
         transforms.RandomCrop(224),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor(),
         transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])
    data = datasets.ImageFolder(root=root_path+dir, transform=transform)
    train_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, drop_last=True, **kwargs)
    return train_loader


def load_testing_CAN(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([256, 256], Image.BICUBIC),
         transforms.CenterCrop(224),
         transforms.ToTensor(),
         transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))]
    )
    data = datasets.ImageFolder(root=root_path+dir, transform=transform)
    test_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, **kwargs)

    return test_loader

# ===== GVB style loading===============


def load_training_GVB(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([256, 256]),
         transforms.RandomCrop(224),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor(),
         transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])
    data = datasets.ImageFolder(root=root_path+dir, transform=transform)
    train_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, drop_last=True, **kwargs)
    return train_loader


def load_testing_GVB(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([256, 256]),
         transforms.CenterCrop(224),
         transforms.ToTensor(),
         transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))]
    )
    data = datasets.ImageFolder(root=root_path+dir, transform=transform)
    test_loader = torch.utils.data.DataLoader(
        data, batch_size=batch_size, shuffle=True, **kwargs)

    return test_loader


if __name__ == '__main__':
    from Config import *
    kwargs = {'num_workers': 8, 'pin_memory': True}

    loader = load_testing(root_path, target_name, batch_size, kwargs)
    print(len(loader))
