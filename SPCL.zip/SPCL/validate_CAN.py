
import os
from utils import *
from Config_CAN import *
import torch
import torch.nn.functional as F
from CANdata.custom_dataset_dataloader import CustomDatasetDataLoader
from CANmodel.model import danet
import CANdata.utils as data_utils
from data_loader import load_testing_CAN as load_testing
# from data_loader import load_training_CAN as load_training

cuda = True
kwargs = {'num_workers': 8, 'pin_memory': True} if cuda else {}


# def save_preds(paths, preds, save_path, filename='preds.txt'):
#     assert(len(paths) == preds.size(0))
#     with open(os.path.join(save_path, filename), 'w') as f:
#         for i in range(len(paths)):
#             line = paths[i] + ' ' + str(preds[i].item()) + '\n'
#             f.write(line)


# target_train_loader = load_training(
#     root_path, target_name, batch_size, kwargs)
'''DSAN-style'''
target_test_loader = load_testing(
    root_path, target_name, batch_size, kwargs)
len_target_dataset = len(target_test_loader.dataset)


'''CAN style'''
# with open(os.path.join(root_path, 'category.txt'), 'r') as f:
#     classes = f.readlines()
#     classes = [c.strip() for c in classes]
# assert(len(classes) == class_num)
# dataroot_T = os.path.join(root_path, target_name)
# test_transform = data_utils.get_transform(False)
# target_test_loader = CustomDatasetDataLoader(dataset_root=dataroot_T,
#                                              dataset_type=DATASET_TYPE, batch_size=batch_size,
#                                              transform=test_transform, train=False,
#                                              num_workers=8, classnames=classes)
# len_target_dataset = len(target_test_loader.dataset)


# def validate(net):          # CAN style
#     res = {}
#     res['path'], res['preds'], res['gt'], res['probs'] = [], [], [], []
#     net.eval()
#     bn_domain_map = weights_dict['bn_domain_map']

#     if target_name in bn_domain_map:
#         domain_id = bn_domain_map[target_name]
#     else:
#         domain_id = 0

#     with torch.no_grad():
#         net.module.set_bn_domain(1)
#         for sample in iter(target_test_loader):
#             # for sample, label in iter(target_test_loader):
#             img = sample['Img'].cuda()
#             # img = sample.cuda()
#             probs = net(img)[1]['probs']
#             res['probs'] += [probs]
#             if 'Label' in sample:
#                 label = sample['Label'].cuda()
#             # label = label.cuda()
#                 res['gt'] += [label]

#         if 'gt' in res and len(res['gt']) > 0:
#             gts = torch.cat(res['gt'], dim=0)
#             probs = torch.cat(res['probs'], dim=0)
#             probs = torch.max(probs, dim=1).indices
#             # print(probs.size(0), probs.size)
#             # output to file
#             with open('seelabel.txt', 'w') as f:
#                 for i in range(probs.size(0)):
#                     line = 'preds: ' + str(probs[i].item()) + 'labels: ' + str(gts[i].item()) + '\n'
#                     f.write(line)
#             f.close()
#             eval_res = 100.0 * torch.sum(probs == gts).item() / probs.size(0)

#             print('Test accuracy: {}/{} ({:.4f}%)'.format(torch.sum(probs == gts).item(), probs.size(0), eval_res))


def validate(model):        # DSAN style
    model.module.set_bn_domain(1)       # set to target domain: 1
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for data, target in target_test_loader:
            if cuda:
                data, target = data.cuda(), target.cuda()
            pred = model(data)[1]['probs']
            # sum up batch loss
            test_loss += F.nll_loss(F.log_softmax(pred, dim=1), target).item()
            # get the index of the max log-probability
            label_pred = pred.data.max(1)[1]
            correct += label_pred.eq(target.data.view_as(label_pred)
                                     ).cpu().sum()
        test_loss /= len_target_dataset

    print('\n{} set: Average loss: {:.4f}, Accuracy: {}/{} ({:.2f}%)\n'.format(
        target_name, test_loss, correct, len_target_dataset,
        100. * correct / len_target_dataset))

    return correct


if __name__ == '__main__':
    '''load CAN model'''
    weights_dict = torch.load(can_weight_path)
    model_state_dict = weights_dict['weights']
    model = danet(num_classes=class_num,
                  state_dict=model_state_dict,
                  feature_extractor=can_backbone,
                  fx_pretrained=False,
                  dropout_ratio=dropout_ratio,
                  fc_hidden_dims=FC_HIDDEN_DIMS,
                  num_domains_bn=num_domains_bn)

    model = torch.nn.DataParallel(model).cuda()
    validate(model)
