seed = 1
log_interval = 10

bottle_neck = True
batch_size = 32     # 36
epochs = 200
cos_anneal = False
momentum = 0.9
l2_decay = 5e-4

lr = 0.01       #
alpha = 20      #
T = 2       #

class_num = 31  # 65 for office-home, 31 for office31
gvb_model_path = '/home/mori/Programming/GVB/office31/GVB-GD/a2d1/best_model.pth.tar'
net2_backbone = 'ResNet50'
tensorboard_path = 'tensorboard_log/office31/'
root_path = "../DatasetCollection/office31/"
source_name = "amazon"           #
target_name = "dslr"         #
