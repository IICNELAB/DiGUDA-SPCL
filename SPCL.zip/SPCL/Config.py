seed = 1
log_interval = 10

bottle_neck = True
batch_size = 32
epochs = 200
cos_anneal = False
momentum = 0.9
l2_decay = 5e-4

lr = 0.01
alpha = 1
T = 2

class_num = 31  # 65 for office-home, 31 for office31
# net1_pickel = True
net1_path = '/home/mori/Programming/DSAN/save_models/office31/d2a/RN50_acc7423.pkl'
net2_backbone = 'ResNet50'
tensorboard_path = 'tensorboard_log/office31/'
root_path = "../DatasetCollection/office31/"
source_name = "dslr"           #
target_name = "amazon"         #
