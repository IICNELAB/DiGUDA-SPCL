import os
from utils import *
from Config_GVB import *
import torch
import torch.nn.functional as F
from network import ResNetFc
from data_loader import load_training_GVB as load_training
from data_loader import load_testing_GVB as load_testing

kwargs = {'num_workers': 8, 'pin_memory': True}

target_test_loader = load_testing(
    root_path, target_name, batch_size, kwargs)
len_target_dataset = len(target_test_loader.dataset)


# def validate(model):
#     start_test = True
#     with torch.no_grad():
#         iter_test = iter(target_test_loader)
#         for i in range(len_target_dataset):
#             data = iter_test.next()
#             inputs = data[0]
#             labels = data[1]
#             inputs = inputs.cuda()
#             labels = labels.cuda()
#             _, outputs, _ = model(inputs)
#             if start_test:
#                 all_output = outputs.float()
#                 all_label = labels.float()
#                 start_test = False
#             else:
#                 all_output = torch.cat((all_output, outputs.float()), 0)
#                 all_label = torch.cat((all_label, labels.float()), 0)
#     _, predict = torch.max(all_output, 1)
#     accuracy = torch.sum(torch.squeeze(predict).float() == all_label).item() / float(all_label.size()[0])
#     print('acc: ', accuracy)

#     return accuracy


def validate(model):
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for data, target in target_test_loader:
            data, target = data.cuda(), target.cuda()
            _, pred, _ = model(data)
            # print(pred.shape)
            # sum up batch loss
            test_loss += F.nll_loss(F.log_softmax(pred, dim=1), target).item()
            # get the index of the max log-probability
            label_pred = pred.data.max(1)[1]
            correct += label_pred.eq(target.data.view_as(label_pred)
                                     ).cpu().sum()
        test_loss /= len_target_dataset

    print('\n{} set: Average loss: {:.4f}, Accuracy: {}/{} ({:.2f}%)\n'.format(
        target_name, test_loss, correct, len_target_dataset,
        100. * correct / len_target_dataset))

    return correct


if __name__ == '__main__':
    '''load GVB model'''
    model = torch.load(gvb_model_path)
    validate(model)
