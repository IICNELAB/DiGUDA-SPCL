import torchvision.transforms as transforms
from PIL import Image
import torch


def get_transform(train=True):
    transform_list = []
    # if cfg.DATA_TRANSFORM.RESIZE_OR_CROP == 'resize_and_crop':
    osize = [256, 256]
    transform_list.append(transforms.Resize(osize, Image.BICUBIC))
    if train:
        transform_list.append(transforms.RandomCrop(224))
    else:
        # if cfg.DATA_TRANSFORM.WITH_FIVE_CROP:
        #     transform_list.append(transforms.FiveCrop(cfg.DATA_TRANSFORM.FINESIZE))
        # else:
        transform_list.append(transforms.CenterCrop(224))

    # if train and cfg.DATA_TRANSFORM.FLIP:
    #     transform_list.append(transforms.RandomHorizontalFlip())

    to_normalized_tensor = [transforms.ToTensor(),
                            transforms.Normalize(mean=(0.485, 0.456, 0.406),
                                                 std=(0.229, 0.224, 0.225))]

    # if not train and cfg.DATA_TRANSFORM.WITH_FIVE_CROP:
    #     transform_list += [transforms.Lambda(lambda crops: torch.stack([
    #         transforms.Compose(to_normalized_tensor)(crop) for crop in crops]))]
    # else:
    transform_list += to_normalized_tensor

    return transforms.Compose(transform_list)
