
import os

from numpy.lib.utils import source
from utils import *
from Config_TSNE import *
import torch
import torch.nn.functional as F
from CANdata.custom_dataset_dataloader import CustomDatasetDataLoader
from CANmodel.model import danet
import CANdata.utils as data_utils
from data_loader import load_testing_CAN as load_testing
# from data_loader import load_training_CAN as load_training
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

cuda = True
kwargs = {'num_workers': 8, 'pin_memory': True} if cuda else {}
print(source_name+'->'+target_name)
source_loader = load_testing(root_path, source_name, 450, kwargs)
target_loader = load_testing(root_path, target_name, 450, kwargs)
# len_target_dataset = len(target_loader.dataset)
# print(len_target_dataset)


def visualize_CAN(model):
    model.module.set_bn_domain(1)       # set to target domain: 1
    model.eval()
    with torch.no_grad():
        # for data, target in target_loader:
        iter_target = iter(target_loader)
        iter_source = iter(source_loader)
        source_data, source_label = iter_source.next()
        target_data, target_label = iter_target.next()
        if cuda:
            target_data, target_label = target_data.cuda(), target_label.cuda()
            source_data, source_label = source_data.cuda(), source_label.cuda()

        source_feat = model(source_data)[0].cpu()
        source_labels = source_label.cpu()
        target_feat = model(target_data)[0].cpu()       # CAN feat:[batchsize, 2048]
        target_labels = target_label.cpu()

        tsne = TSNE(n_components=2, perplexity=30, init='pca', random_state=0)
        feat_all = torch.cat((source_feat, target_feat), dim=0)
        f_all = tsne.fit_transform(feat_all)
        s_f, t_f = np.array_split(f_all, 2, axis=0)
        # print(s_f.shape)

        sx_min, sx_max = np.min(s_f, 0), np.max(s_f, 0)
        tx_min, tx_max = np.min(t_f, 0), np.max(t_f, 0)
        data_s = (s_f - sx_min) / (sx_max - sx_min)     # feature normailize
        data_t = (t_f - tx_min) / (tx_max - tx_min)
        del s_f, t_f

        plt.scatter(data_s[:, 0], data_s[:, 1], s=10, c='b', marker='.')
        plt.scatter(data_t[:, 0], data_t[:, 1], s=10, c='r', marker='.')
        plt.xticks([])
        plt.yticks([])
        # plt.title('T-SNE')
        plt.savefig('tsne.png')
        plt.show()

    return


def visualize_net2(model):
    model.eval()
    with torch.no_grad():
        # for data, target in target_loader:
        iter_target = iter(target_loader)
        iter_source = iter(source_loader)
        source_data, source_label = iter_source.next()
        target_data, target_label = iter_target.next()
        if cuda:
            target_data, target_label = target_data.cuda(), target_label.cuda()
            source_data, source_label = source_data.cuda(), source_label.cuda()
        source_feat = model(source_data)[0].cpu()
        source_labels = source_label.cpu()
        target_feat = model(target_data)[0].cpu()
        target_labels = target_label.cpu()
        print(source_feat.shape)
        print(target_feat.shape)

        tsne = TSNE(n_components=2, perplexity=30, init='pca', random_state=0)
        feat_all = torch.cat((source_feat, target_feat), dim=0)
        f_all = tsne.fit_transform(feat_all)
        s_f, t_f = np.array_split(f_all, 2, axis=0)
        # print(s_f.shape)
        # print(t_f.shape)

        sx_min, sx_max = np.min(s_f, 0), np.max(s_f, 0)
        tx_min, tx_max = np.min(t_f, 0), np.max(t_f, 0)
        data_s = (s_f - sx_min) / (sx_max - sx_min)     # feature normailize
        data_t = (t_f - tx_min) / (tx_max - tx_min)
        del s_f, t_f

        plt.scatter(data_s[:, 0], data_s[:, 1], s=10, c='b', marker='.')
        plt.scatter(data_t[:, 0], data_t[:, 1], s=10, c='r', marker='.')
        plt.xticks([])
        plt.yticks([])
        # plt.title('T-SNE')
        plt.savefig('tsne1.png')
        plt.show()

    return


if __name__ == '__main__':

    # =========== SPCL ========================
    '''visualize CAN model'''
    # weights_dict = torch.load(can_weight_path)
    # model_state_dict = weights_dict['weights']
    # model = danet(num_classes=31,
    #               state_dict=model_state_dict,
    #               feature_extractor='resnet50',
    #               fx_pretrained=False,
    #               dropout_ratio=(0.0,),
    #               fc_hidden_dims=(),
    #               num_domains_bn=2)
    # model = torch.nn.DataParallel(model).cuda()
    # visualize_CAN(model)

    '''lovisualizead DSAN model'''
    model = torch.load(dsan_path)
    # print(model)
    visualize_net2(model)

    '''visualize DAN model'''
    # model = torch.load(dan_path)
    # # print(model)
    # visualize_net2(model)

    '''visualize net2 model'''
    # model = torch.load(net2_path)
    # # print(model)
    # visualize_net2(model)
