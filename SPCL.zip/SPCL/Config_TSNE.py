seed = 1
log_interval = 10

bottle_neck = True
batch_size = 32
epochs = 200
cos_anneal = False
momentum = 0.9
l2_decay = 5e-4
can_backbone = 'resnet50'
DATASET_TYPE = 'SingleDataset'
dropout_ratio = (0.0,)
FC_HIDDEN_DIMS = ()
num_domains_bn = 2

lr = 0.01
alpha = 1
T = 2

class_num = 31  # 65 for office-home, 31 for office31
# dan_path = '/home/mori/Programming/DAN/save_models/office31/a2d/RN50_acc8353.pkl'
# can_weight_path = '/home/mori/Programming/CAN/experiments/ckpt/office31_w2a/acc7650.weights'        #
dsan_path = '/home/mori/Programming/StageKD/save_models/net1/DSAN/office31/a2d/RN50_acc9116.pkl'
# net2_path = '/home/mori/Programming/StageKD/save_models/net2/office31/CAN/w2a/RN50_acc7725.pkl'

net2_backbone = 'ResNet50'
tensorboard_path = 'tensorboard_log/office31/'
root_path = "../DatasetCollection/office31/"
source_name = "dslr"           #
target_name = "amazon"         #
